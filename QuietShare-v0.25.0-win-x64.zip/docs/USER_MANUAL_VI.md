# Hướng dẫn sử dụng QuietShare

> **Có hướng dẫn bằng ảnh:** [Xem 8 ảnh chụp giao diện có đánh số và khoanh đỏ](VISUAL_GUIDE_VI.md).

Ấn bản tiếng Việt - QuietShare v0.25.0

Đọc, chuẩn bị và thuyết trình với lời nhắc riêng trên Windows.

[Bản PDF](QuietShare-Huong-Dan-Su-Dung-VI.pdf) | [Ấn bản tiếng Anh](USER_MANUAL_EN.md) | [Bản phát hành mới nhất](https://github.com/TDUmii/QuietShare/releases/latest)

## 1. Bắt đầu từ đây

QuietShare hỗ trợ đọc lời nhắc, tài liệu cục bộ và trang web tùy chọn khi thuyết trình. Cửa sổ điều khiển riêng của ứng dụng tách biệt với tài liệu bạn muốn đưa cho người xem.

Smart Mirror thu màn hình nguồn công khai đã chọn rồi dựng hình lên màn hình thứ hai. Ứng dụng kiểm tra QuietShare được loại khỏi đường thu hình đã xác minh trước khi cho hiện nội dung riêng. Kiểm tra đạt chỉ mô tả đường thu hình cục bộ đó. Bạn vẫn cần quan sát máy chiếu, TV, đầu nhận cuộc họp hoặc bản ghi thực tế.

### Chọn tình huống sử dụng

- **Đọc trên một màn hình:** mở file cục bộ hoặc soạn lời nhắc sau khi xác minh capture. Không bắt buộc dùng Smart Mirror.
- **Chiếu qua máy chiếu hoặc màn hình có dây:** dùng Extend của Windows với hai màn khác nhau cùng GPU. Làm theo chương 10.
- **Chiếu qua TV không dây:** trước tiên cần tạo màn hình Windows riêng cho TV. Làm theo chương 11.
- **Chia sẻ trong cuộc họp:** dùng điều khiển của ứng dụng họp để chia sẻ cửa sổ ứng dụng công khai gốc. Làm theo chương 12.
- **Ghi hình bằng OBS:** chọn và kiểm tra đúng nguồn công khai được thu. Làm theo chương 12.

Không chọn cửa sổ QuietShare riêng làm tài liệu công khai. F8 che nội dung riêng và dừng trình chiếu QuietShare. Phím này không tắt chia sẻ màn hình của ứng dụng họp hoặc dừng ghi OBS.

### Yêu cầu

- Windows 10 phiên bản 2004, build 19041 trở lên hoặc Windows 11.
- Windows 64 bit.
- Desktop Window Manager (DWM) và Windows Graphics Capture (WGC) hoạt động.
- Smart Mirror cần hai màn Extend khác nhau, được nhận diện trên cùng adapter đồ họa.
- Trình duyệt tùy chọn cần Microsoft Edge WebView2 Runtime.

Trình đọc file cục bộ hoạt động ngoại tuyến và không cần bộ máy trình duyệt. Chưa hỗ trợ trình chiếu giữa hai adapter khác nhau. Chế độ Duplicate khóa nội dung riêng.

### Buổi dùng thử đầu tiên

1. Cài QuietShare hoặc giải nén toàn bộ gói portable.
2. Mở ứng dụng và đợi xác minh capture.
3. Đọc trạng thái bảo vệ. Nếu bị khóa, xử lý điều kiện hiển thị trước khi mở lời nhắc riêng.
4. Mở một file text không chứa thông tin nhạy cảm bằng Ctrl+O.
5. Chỉnh cỡ chữ, độ đậm và xuống dòng cho phù hợp laptop.
6. Thử F8 để làm quen thao tác che trước khi thuyết trình.
7. Nếu có người xem, hoàn thành quy trình tương ứng và kiểm tra đầu nhận bằng tài liệu mẫu.

Nút Play trình chiếu và nút chạy cuộn của trình đọc có tác dụng khác nhau. F10 bắt đầu hoặc dừng Smart Mirror. Space chạy hoặc tạm dừng cuộn trong vùng đọc.

## 2. Cài đặt, cập nhật và gỡ ứng dụng

Tải từ [trang phát hành QuietShare](https://github.com/TDUmii/QuietShare/releases/latest). Dùng các thành phần thuộc cùng một bản phát hành. Không ghép EXE của bản này với thư viện của bản khác.

### Cài cho tài khoản hiện tại

1. Đóng bản QuietShare cũ đang chạy.
2. Tải **QuietShare-Setup.exe**.
3. Chạy bộ cài và chọn tiếng Anh hoặc tiếng Việt.
4. Hoàn thành cài đặt cho tài khoản Windows đang dùng. Không cần quyền quản trị.
5. Mở QuietShare và kiểm tra phiên bản trên Home.

Windows có thể áp dụng kiểm tra thông thường cho ứng dụng tải xuống. Dùng bản phát hành từ kho của dự án và tuân theo quy định cài phần mềm của tổ chức bạn.

### Dùng gói portable

1. Tải toàn bộ ZIP Windows x64 có số phiên bản.
2. Giải nén vào thư mục cục bộ bình thường trước khi chạy.
3. Giữ các file sau cạnh nhau:
   - QuietShare.exe
   - Scintilla.dll
   - Lexilla.dll
   - pdfium.dll
   - WebView2Loader.dll
4. Giữ tài liệu và giấy phép đi kèm trong gói.
5. Chạy QuietShare.exe từ thư mục đã giải nén.

Chỉ tải EXE hoặc chạy trực tiếp trong cửa sổ xem ZIP không tạo thành bản portable đầy đủ.

### Cập nhật

1. Lưu các file văn bản hoặc code đang sửa.
2. Dừng trình chiếu và đóng QuietShare.
3. Nếu đã cài ứng dụng, chạy bộ cài mới.
4. Nếu dùng portable, giải nén toàn bộ gói mới vào thư mục riêng rồi chạy bản đó.
5. Xác nhận phiên bản mới trên Home.
6. Kiểm tra lại đầu ra thực tế phía người xem trước buổi thuyết trình có lời nhắc riêng tiếp theo.

Nâng cấp bằng bộ cài giữ lời nhắc đã lưu. Với tài liệu quan trọng, duy trì bản sao riêng theo cách sao lưu thông thường của bạn.

### Gỡ ứng dụng

1. Lưu công việc và đóng QuietShare.
2. Với bản cài đặt, mở danh sách ứng dụng đã cài của Windows rồi gỡ QuietShare.
3. Với bản portable, xóa thư mục ứng dụng đã giải nén sau khi đóng chương trình.

Gỡ ứng dụng không xóa lời nhắc đã lưu hoặc toàn bộ dữ liệu người dùng cục bộ. Bản portable cũng lưu cấu hình và lời nhắc trong hồ sơ người dùng Windows. Xóa thư mục ứng dụng portable không xóa hồ sơ đó. Nếu muốn xóa lịch sử gần đây, dùng chức năng xóa lịch sử riêng trong QuietShare.

## 3. Home và không gian làm việc

Home giúp mở nhanh file và thư mục dự án bạn thực sự đã dùng. Ứng dụng không chèn các file minh họa vào lịch sử gần đây.

Tiêu đề **Trang chủ** gọn có nút chính **Mở file** và nút viền **Mở dự án**. Công việc gần đây hiển thị thành danh sách phẳng toàn chiều rộng, trạng thái bảo vệ nằm trong khu vực riêng. Thanh biểu tượng gọn có chú giải cho từng không gian làm việc. Thanh công cụ và tab của file, PDF và trình duyệt dùng các điều khiển phẳng đồng nhất.

![Trang chủ QuietShare](quietshare-home.png)

Hình minh họa bố cục Home. Phiên bản, ngôn ngữ, lịch sử và kết quả bảo vệ của bạn có thể khác.

### Mở lại công việc gần đây

1. Chọn **Tổng quan** ở thanh bên để về Home.
2. Tìm file hoặc dự án trong danh sách gần đây.
3. Chọn mục để mở lại.
4. Dùng nút trang trước hoặc trang sau khi có nhiều mục.

File hoặc thư mục gốc vẫn phải còn ở vị trí cục bộ tương ứng. Mục gần đây là lối tắt đến vị trí đó, không phải bản sao lưu được nhúng trong ứng dụng.

### Ghim hoặc xóa một mục

- Chọn nút ghim cạnh mục để giữ trong nhóm yêu thích.
- Chọn lại để bỏ ghim.
- Dùng nút xóa cạnh mục để xóa riêng mục lịch sử đó.
- Chọn **Xóa lịch sử** để xóa toàn bộ mục gần đây, gồm cả ghim.

Các thao tác này không xóa file hoặc thư mục gốc. Xóa lịch sử không đóng tài liệu đang mở.

### Dùng thanh bên

- **Tổng quan** trở về Home.
- **Tệp đang mở** trở về tài liệu hiện tại.
- Nhấp phải **Tệp đang mở** để chọn file khác hoặc soạn lời nhắc.
- **Trình duyệt** mở không gian duyệt web tùy chọn.
- **Kiểm tra WGC** xác minh capture. Nút Play hoặc Dừng trình chiếu bắt đầu hoặc dừng Smart Mirror.
- **Cài đặt** có giao diện, đọc/tệp, trình chiếu, trình duyệt, cuộc họp, bố cục, phím tắt và dữ liệu.

Di chuột để đọc chú giải các nút biểu tượng nhỏ. Với màn hình laptop nhỏ, ẩn thanh không cần thiết trong Bố cục hoặc dùng F11 để tập trung.

### Mở thư mục dự án

1. Chọn **Mở dự án** hoặc nhấn Ctrl+Shift+O.
2. Chọn thư mục cục bộ trong hộp chọn được bảo vệ.
3. Mở rộng các thư mục trong Explorer.
4. Nhấp đúp file hoặc chọn file rồi nhấn Enter.
5. Dùng Ctrl+B để ẩn hoặc hiện Explorer.

Explorer bỏ qua junction và liên kết tượng trưng. Thư mục ẩn và thư mục phát triển nặng được lọc theo mặc định. Bật tùy chọn hiện các thư mục này khi cần thêm mục. Mở dự án không thực thi code hoặc cài thư viện của dự án đó.

### Chuyển nhanh và bộ thuyết trình

- Nhấn **Ctrl+K**, hoặc chọn **Chuyển nhanh** trong menu bố cục hay menu thêm.
- Tìm theo tên tài liệu, đường dẫn đầy đủ, tiêu đề web hoặc địa chỉ. Dùng phím lên/xuống và Enter, hoặc nhấp đúp vào kết quả. Escape quay lại trang trước.
- Chọn **Bộ thuyết trình**, nhập tên rồi bấm **Lưu bộ**. Tối đa tám bộ được lưu cục bộ, mã hóa theo tài khoản Windows.
- Mỗi bộ gồm lời nhắc, thư mục dự án, thứ tự file, file đang xem và vị trí đọc. Bộ dùng đường dẫn tới file gốc, không sao chép tài liệu.
- Lưu các file đang sửa trước khi lưu bộ. Lưu bộ không ghi các thay đổi chưa lưu vào file gốc.
- Chọn bộ và bấm **Mở**. Xác nhận thay các tab hiện tại, sau đó xử lý file chưa lưu nếu có. File không tìm thấy được bỏ qua và báo lại.
- Mở bộ không tự bật trình duyệt, ghi âm hay trình chiếu.
- Lời nhắc trước khi mở bộ được giữ tại `notes-before-set.dpapi`. Để khôi phục, đóng QuietShare, giữ một bản sao `notes.dpapi`, sao chép `notes-before-set.dpapi` đè lên `notes.dpapi`, rồi mở lại bằng cùng tài khoản Windows. Bản dự phòng này được thay trong lần mở bộ tiếp theo.
- **Xóa bộ** chỉ xóa bộ đã lưu sau khi xác nhận. Các tài liệu gốc vẫn nằm trên đĩa.

## 4. Mở, chỉnh sửa và lưu file

Dùng **Mở file**, Ctrl+O hoặc thả file cục bộ. Hộp chọn được bảo vệ có các vị trí quen thuộc như Desktop, Downloads, Documents, Pictures và các ổ đĩa.

### Chọn và chuyển file

1. Mở hộp chọn bằng Ctrl+O.
2. Chọn vị trí nhanh hoặc đi đến thư mục chứa file.
3. Chọn file và xác nhận.
4. Dùng tab tài liệu hoặc nhấp phải **Tệp đang mở** để chuyển tài liệu.
5. Dùng Ctrl+Tab và Ctrl+Shift+Tab để chuyển tài liệu tiếp hoặc trước trên trang tài liệu đang hoạt động.

Có thể mở tối đa 32 tài liệu, tính cả lời nhắc tùy chọn. Một lần thả file nhận tối đa 31 file. Vị trí xem được giữ khi chuyển trong cùng phiên. Các tab không tự khôi phục khi khởi động lại. Dùng bộ thuyết trình đã lưu để mở lại tài liệu đã chuẩn bị.

### Nội dung cục bộ được hỗ trợ

- **Văn bản và code:** tối đa 5 MiB. Hỗ trợ UTF-8 và UTF-16 có dấu thứ tự byte. Đuôi file lạ phải chứa văn bản hợp lệ được hỗ trợ, không phải dữ liệu nhị phân.
- **Ảnh:** PNG, JPEG, BMP và khung đầu GIF. Tối đa 25 MiB và 40 megapixel.
- **PDF:** tối đa 64 MiB và 10.000 trang. Chưa hỗ trợ PDF có mật khẩu.
- **Đường dẫn:** file và thư mục cục bộ. Chưa hỗ trợ đường dẫn mạng, tệp thực thi, bộ cài, tệp nén hoặc nhị phân tùy ý.

Nếu bản gốc không mở được, dùng một bản đã chuyển sang định dạng phù hợp. Đổi đuôi file nhị phân thành đuôi text không chuyển đổi nội dung.

### Sửa văn bản hoặc code

Mặc định cho phép chỉnh sửa. Ảnh và PDF vẫn chỉ đọc. Code được xem và sửa như văn bản, không bao giờ được thực thi.

1. Mở file văn bản hoặc code.
2. Thực hiện thay đổi cần thiết.
3. Xem dấu thay đổi cạnh tên tài liệu.
4. Chọn **Lưu** hoặc nhấn Ctrl+S.
5. Đọc thông báo lỗi lưu nếu có trước khi đóng tài liệu.

Khi lưu, ứng dụng giữ mã hóa và dấu thứ tự byte được hỗ trợ. Cỡ chữ, độ đậm và xuống dòng khi đọc không ghi định dạng vào file văn bản thuần.

Để chỉ xem, tắt **Cài đặt > Đọc & tệp > Cho phép sửa file**. Lưu các thay đổi đang có trước khi đổi chế độ.

### File thay đổi bên ngoài và đóng tài liệu

QuietShare từ chối ghi đè khi file đã thay đổi trong ứng dụng khác.

1. Giữ bản đang sửa nếu vẫn cần các thay đổi đó.
2. Xem file đã bị ứng dụng khác thay đổi.
3. Lưu hoặc sao chép phần bản nháp cần giữ.
4. Chỉ dùng **Tải lại** khi sẵn sàng thay bản đang xem bằng nội dung trên ổ đĩa.

Đóng file đang sửa có lựa chọn lưu, bỏ thay đổi hoặc hủy. Bản sửa file giữ trong bộ nhớ đến khi bạn chủ động lưu. Nó không tự ghi đè lời nhắc hoặc file gốc.

### Sắp xếp và cuộn trong hộp mở tệp được bảo vệ

- **Tìm tên** lọc tên đã tải trong thư mục, không phân biệt hoa thường. Nhấn Enter để mở file khớp duy nhất.
- Bấm **Tên**, **Loại**, **Ngày sửa** hoặc **Kích thước**. Bấm lại để đảo chiều. Tên có số xếp tự nhiên. Thư mục luôn trước.
- **Sắp xếp** có cùng tiêu chí và lựa chọn tăng/giảm dần. Đổi thứ tự giữ đúng tệp đã chọn.
- **Chi tiết** hiện thông tin. **Danh sách gọn** dành chỗ cho tên. Cửa sổ hẹp tự dùng danh sách, mở rộng phục hồi Chi tiết. Lựa chọn giữ trong phiên chạy.
- Con lăn nhận cả nấc nhỏ khi danh sách chưa có focus. Lối tắt Desktop/Downloads và điều hướng bàn phím vẫn dùng được.
- Bộ lọc chỉ xét tối đa 1.000 tên đã tải trong thư mục, không quét thư mục con.

## 5. Chuẩn bị lời nhắc và đọc dễ hơn

Lời nhắc là bản nháp cục bộ tùy chọn để chuẩn bị lời nói. Nó tách biệt với file nhập vào và không cần chiếm một tab tài liệu thường trực.

### Soạn lời nhắc

1. Nhấp phải **Tệp đang mở** ở thanh bên.
2. Chọn **Soạn lời nhắc**.
3. Nhập hoặc dán nội dung cần dùng.
4. Đợi tự lưu cục bộ hoàn thành.
5. Nhấn Ctrl+Enter để chuyển giữa soạn và đọc.

Lời nhắc tự lưu trên máy. Vùng soạn lời nhắc nhận tối đa 500.000 ký tự. Đây là giới hạn riêng, khác với mức 5 MiB của file text nhập vào.

Văn bản và code nhập từ file dùng thao tác Lưu chủ động. Chuyển tài liệu không thay lời nhắc đã lưu bằng file vừa mở.

### Sổ ghi chép cuộc họp

Mở **Cuộc họp** ở thanh bên để ghi âm, duyệt đoạn có giờ và xuất ghi chép. Chọn ngôn ngữ, mô hình Whisper cục bộ tùy chọn và thư mục xuất tại **Cài đặt > Cuộc họp**. Xem quy trình đầy đủ ở chương 12.

### Cuộn khi trình bày

1. Chuyển lời nhắc sang chế độ đọc.
2. Chọn tốc độ cuộn chậm, vừa hoặc nhanh.
3. Nhấn Space trong vùng đọc hoặc dùng nút Chạy của vùng đó.
4. Nhấn Space lần nữa để tạm dừng.
5. Dừng cuộn trước khi chuyển tài liệu hoặc tab trình duyệt.

Cuộn tự động dành cho đọc văn bản. Nó không lật trang PDF, cuộn ảnh hoặc bật Smart Mirror. F8 dừng cuộn, đồng thời che nội dung riêng và dừng trình chiếu.

### Cỡ chữ, độ đậm và xuống dòng

- Dùng thanh công cụ xem để tăng hoặc giảm cỡ chữ.
- Nhập cỡ chính xác theo pt rồi nhấn Enter để áp dụng.
- Văn bản và lời nhắc hỗ trợ 8-200 pt.
- Chọn Thường, Vừa hoặc Đậm cho văn bản và lời nhắc.
- Bật Xuống dòng để đưa phần dài của dòng xuống hàng hiển thị tiếp theo.
- Tắt xuống dòng khi cần giữ bố cục dòng gốc.

Mặc định văn bản và lời nhắc là 12 pt, tương ứng tỷ lệ ban đầu 50%. Ctrl+0 trở về mặc định của nội dung đang xem. Code, ảnh, PDF và web có điều khiển zoom riêng.

Đổi cỡ, độ đậm, xuống dòng và theme giữ điểm đọc và vùng chọn trong các trường hợp được hỗ trợ. Điều này giúp chỉnh một lời nhắc dài khi đang đọc dở.

### Chuyển giữa lời nhắc, file và web

1. Tạm dừng cuộn tự động.
2. Chọn tài liệu cần dùng từ **Tệp đang mở** hoặc tab của nó.
3. Với web, chọn Trình duyệt rồi chọn tab cần xem.
4. Quay về tài liệu hiện tại qua **Tệp đang mở**.
5. Kiểm tra đoạn đang hiện trước khi tiếp tục cuộn.

Không gian trình duyệt không yêu cầu quay lại một tab Lời nhắc thường trực. Chỉ giữ tài liệu và tab web thực sự cần cho phiên làm việc.

## 6. Xem tài liệu và chọn giao diện màu

QuietShare bắt đầu zoom nội dung ở 50%. Đây là cài đặt vùng xem nội dung, không phải yêu cầu đổi tỷ lệ màn hình Windows. Chọn kích thước dễ đọc trên màn của bạn.

### Code và ảnh

- Code có trình xem nhận diện cú pháp và nút xuống dòng.
- Code, ảnh và PDF có zoom 25-400%.
- Dùng nút zoom hoặc Ctrl+- và Ctrl++ trong trình xem tương ứng.
- Ctrl+0 trở về tỷ lệ nội dung mặc định.
- Trình xem ảnh giữ màu điểm ảnh. Theme không đổi màu bức ảnh.
- GIF chỉ hiện khung hình đầu tiên.

Nếu dòng code quá dài, bật xuống dòng. Khi cần xem thụt lề hoặc căn hàng, giữ bố cục dòng gốc và di chuyển ngang nếu cần.

### Đọc PDF

1. Mở PDF cục bộ được hỗ trợ.
2. Dùng nút trang trước và trang sau cạnh số trang / tổng số trên thanh công cụ PDF. Các nút vẫn hiển thị trong chế độ tập trung và khi ẩn thanh công cụ chính.
3. Dùng con lăn, thanh cuộn, Lên/Xuống hoặc Page Up/Page Down để cuộn liên tục qua các trang liền nhau. Trái/Phải và nút trang nhảy đến trang cụ thể. Menu mở rộng vẫn có vừa chiều ngang.
4. Con lăn giữ phần dịch chuyển khi qua ranh giới trang, không đặt từng trang lại về đầu. Cuộn nhỏ cũng di chuyển vùng đọc. Ctrl+con lăn để zoom. Kéo vùng trống để di chuyển. Chuyển không gian làm việc vẫn giữ vị trí đọc.
5. Kéo trên chữ để chọn nếu PDF có lớp văn bản.
6. Dùng Ctrl+F để tìm trong phần chữ có thể tìm kiếm.

### Công cụ trang và lời nhắc gắn trang

1. Mở menu thanh công cụ PDF để chọn **Ảnh thu nhỏ các trang**, **Các trang đã đánh dấu** hoặc **Đánh dấu trang này**.
2. Chọn ảnh thu nhỏ để chuyển trang. Chọn bộ đếm trang để nhập số rồi bấm **Đến**. Số trang bắt đầu từ 1.
3. Chuẩn bị lời nhắc bằng các tiêu đề Markdown như `# Mở đầu` và `## Chi tiết`.
4. Mở **Lời nhắc theo trang** trong menu PDF. Chọn phần lời nhắc, đến trang PDF tương ứng rồi bấm **Gắn trang**.
5. Chỉ bật **Đồng bộ** khi cần. Đổi trang PDF chọn phần đã gắn gần nhất. Nút phần trước/sau chuyển đến trang đã gắn. Phần chưa gắn vẫn đọc được.
6. Chỉnh vùng lời nhắc bằng A- / A+. Vị trí đang đọc được giữ khi đổi cỡ hoặc độ đậm chữ.
7. Cửa sổ rộng đặt lời nhắc bên cạnh PDF. Cửa sổ nhỏ đưa lời nhắc xuống dưới. Có thể ẩn từng vùng khi không cần.

Ảnh thu nhỏ chỉ dựng cho các dòng đang thấy. Bộ đệm LRU giới hạn 12 ảnh và 2 MiB, tách khỏi bộ đệm các vùng trang đang thấy. Ẩn cột trang sẽ giải phóng bộ đệm ảnh thu nhỏ. Dấu trang và liên kết lời nhắc được mã hóa cục bộ, tối đa 32 PDF, 64 dấu trang và 128 liên kết mỗi PDF. PDF gốc giữ nguyên.

Trang quét không có lớp chữ sẽ không cung cấp tìm hoặc sao chép văn bản thông thường. QuietShare dựng phần đang thấy của các trang liền nhau. Tối đa tám bitmap vùng cắt dùng chung giới hạn 48 MiB. Trình xem dùng chung dữ liệu PDF gốc thay vì sao chép. Ứng dụng không sửa nội dung PDF hoặc gỡ mật khẩu.

### Tìm chữ

1. Nhấn Ctrl+F.
2. Nhập từ cần tìm.
3. Nhấn Enter để đến kết quả tiếp.
4. Nhấn Shift+Enter để về kết quả trước.
5. Nhấn Esc để đóng vùng tìm kiếm.

Cách tìm tùy trình xem đang hoạt động. Tìm chữ trong PDF cần lớp văn bản.

### Chọn mười theme có sẵn hoặc tự thiết kế màu

Mở **Cài đặt > Giao diện > Chủ đề màu** hoặc dùng nút theme trên thanh công cụ xem.

- Đơn sắc tối (mặc định)
- Đơn sắc sáng
- Giấy ấm
- Xanh đêm
- Rừng đêm
- Than chì
- Sương xanh
- Xanh ban ngày
- Đen tương phản cao
- Trắng tương phản cao

Chọn **Tùy chỉnh** để sửa màu nền, bảng, chữ và màu nhấn. Các bề mặt và viền liên quan được tự tạo để giữ bảng màu đồng nhất. **Khôi phục màu theme mặc định** đưa màu tùy chỉnh về ban đầu.

Thử theme sáng hoặc tương phản cao trong phòng nhiều ánh sáng. Thử Giấy ấm nếu muốn nền đọc dịu hơn. Lựa chọn được nhớ qua các lần mở ứng dụng. Theme đổi giao diện QuietShare và phần trình bày chữ. Nó không đổi màu nội dung website, điểm ảnh hoặc trang PDF.

Nếu chữ nhạt, tăng độ mờ cửa sổ về gần 100%, sau đó chỉnh cỡ và độ đậm. Hình thức phông chữ còn phụ thuộc tỷ lệ Windows, màn hình và cài đặt đồ họa.

## 7. Cài đặt, bố cục và phím tắt

Cài đặt có tám nhóm: **Giao diện**, **Đọc & tệp**, **Trình chiếu**, **Trình duyệt**, **Cuộc họp**, **Bố cục**, **Phím tắt** và **Dữ liệu**. Cửa sổ rộng có danh mục bên trái. Cửa sổ nhỏ hoặc thấp hiện đủ tám nhóm thành một hoặc hai hàng nút để bấm trực tiếp. Cuộn trong nhóm đang mở. **Giao diện > Nâng cao** chứa độ mờ, cỡ icon và màu tự chọn.

### Lưu hồ sơ sử dụng

1. Chỉnh theme, cỡ/độ đậm/xuống dòng, các thanh hiển thị, chiều rộng Explorer và xem trước.
2. Mở **Cài đặt > Bố cục**, chọn **Đọc trên laptop**, **Thuyết trình** hoặc **Ghi chép cuộc họp**.
3. Chọn **Lưu hiện tại**. Ban đầu cả ba ô đều trống. Lưu sẽ thay riêng ô đang chọn.
4. Khi cần, chọn lại ô đó và nhấn **Áp dụng**.

Hồ sơ giữ theme/màu riêng, cách đọc chữ, zoom tài liệu, tốc độ cuộn, độ mờ, cỡ icon, bố cục, ghim, xem trước và chế độ tài nguyên. Dữ liệu được mã hóa cho tài khoản Windows hiện tại. Áp dụng tác động trình đọc đang mở. Thao tác không bật trình duyệt, ghi âm hoặc trình chiếu, không đổi quyền thiết bị và không thay lời nhắc/file. Hồ sơ khác với bộ thuyết trình lưu tài liệu và vị trí đọc.

Dùng **Dữ liệu > Xóa lịch sử** để bỏ các mục gần đây và ghim. File gốc và bộ thuyết trình đã lưu vẫn được giữ.

### Chỉnh cửa sổ cho thuận tiện

- Đổi ngôn ngữ giao diện trong Giao diện.
- Bật hoặc tắt nhớ kích thước cửa sổ lần cuối. Mặc định bật.
- Ghim cửa sổ điều khiển trên cùng khi cần nhìn lời nhắc liên tục.
- Chỉnh độ mờ 40-100%. Thao tác tác động cả chữ của cửa sổ điều khiển. Hình chiếu công khai vẫn đục.
- Chỉnh icon 12-24 px.
- Trong **Bố cục**, chọn riêng nhãn dạng số cho tab tài liệu và tab Browser khi tiêu đề chiếm nhiều chỗ. Tooltip của tab vẫn hiện đường dẫn hoặc địa chỉ đầy đủ.
- Hàng **Hiển thị tab dạng Tab 1, Tab 2, ...** cho phép bật riêng cho Lời nhắc/file và Trình duyệt. Các tab liền nhau dùng một dải thống nhất, còn tooltip vẫn hiện tên đầy đủ.
- Dùng Bố cục để ẩn hoặc hiện thanh hoạt động, tab, công cụ, trạng thái và Explorer.
- Kéo đường chia Explorer để đổi chiều rộng.
- Dùng F11 để vào hoặc thoát chế độ tập trung.

Với màn hình nhỏ, trước tiên ẩn bảng không cần dùng. Sau đó chỉnh cỡ chữ. Giảm độ mờ có thể làm chữ khó đọc ngay cả khi theme đang có độ tương phản cao.

### Chế độ tài nguyên

Nút tài nguyên chuyển giữa Tiết kiệm 15 FPS, Cân bằng 30 FPS và Hiệu năng 60 FPS. Đây là giới hạn xử lý trình chiếu. Nó không bảo đảm màn hình dựng đúng số khung hình đó.

Bắt đầu với Cân bằng cho slide thông thường. Tiết kiệm có thể đủ với nội dung chủ yếu đứng yên. Hiệu năng có thể hữu ích với chuyển động khi GPU và màn đáp ứng được. Đóng tab web không dùng nếu website tốn tài nguyên. Việc nghỉ của tab nền vẫn phụ thuộc WebView2 và trang web.

### Phím tắt mặc định

| Phím | Thao tác |
|---|---|
| F8 | Che hoặc mở nội dung riêng khi bảo vệ cho phép. Che sẽ dừng chiếu và cuộn. |
| Ctrl+Alt+Q | Gọi QuietShare, giữ focus tiền cảnh và trạng thái che. |
| F9 | Xác minh đường thu hình WGC. |
| F10 | Bắt đầu hoặc dừng trình chiếu Smart Mirror. |
| F11 | Vào hoặc thoát chế độ tập trung. |
| Ctrl+O | Mở file. |
| Ctrl+Shift+O | Mở thư mục dự án. |
| Ctrl+B | Ẩn hoặc hiện Explorer. |
| Ctrl+S | Lưu file văn bản hoặc code đang cho phép sửa. |
| Ctrl+Tab | Đến tài liệu hoặc tab web tiếp trên trang đang dùng. |
| Ctrl+Shift+Tab | Đến tài liệu hoặc tab web trước. |
| Ctrl+Enter | Chuyển soạn và đọc lời nhắc. |
| Space | Chạy hoặc tạm dừng cuộn tự động trong vùng đọc. |
| Ctrl+F | Tìm trong trình xem được hỗ trợ đang hoạt động. |
| Ctrl+- / Ctrl++ | Giảm hoặc tăng cỡ chữ hay zoom nội dung hiện tại. |
| Ctrl+0 | Khôi phục cỡ hoặc zoom mặc định của nội dung hiện tại. |
| Ctrl+T / Ctrl+W | Mở hoặc đóng tab web trong ngữ cảnh trình duyệt. |

F8 và Ctrl+Alt+Q chỉ dùng toàn hệ thống khi đăng ký với Windows thành công. Các phím khác tùy vùng nhận focus và trang đang hoạt động.

Để đổi một trong mười phím tắt tùy chỉnh:

1. Mở **Cài đặt > Phím tắt**.
2. Chọn tổ hợp cần đổi.
3. Nhấn tổ hợp mới.
4. Đọc thông báo trùng hoặc phím dành riêng nếu có.
5. Nhấn Esc để hủy thay đổi chưa hoàn thành.

Tổ hợp trùng hoặc dành riêng sẽ bị từ chối. Ứng dụng khác giữ phím có thể khiến đăng ký toàn hệ thống thất bại. Khi đó dùng điều khiển trên màn hình hoặc phím dự phòng cục bộ.

## 8. Dùng trình duyệt tùy chọn

Trình duyệt tắt ở mỗi lần mở ứng dụng. Tính năng cần Microsoft Edge WebView2 Runtime. Bật từ không gian Trình duyệt hoặc **Cài đặt > Trình duyệt** khi cần.

Cập nhật tiêu đề/trạng thái web liên tục được gom lại để tránh dàn lại toàn bộ giao diện quá nhiều lần. Trang web ẩn không gây dàn lại vùng đọc file/lời nhắc đang dùng. Nếu WebView2 từ chối cho tab nền nghỉ, QuietShare yêu cầu mức bộ nhớ thấp hơn khi runtime hỗ trợ và trả về mức bình thường khi quay lại. Controller và nội dung chưa gửi vẫn được giữ. Tối ưu này không bỏ hoặc tải lại tab. Mức giảm bộ nhớ còn tùy website và runtime.

### Mở trang

1. Bật trình duyệt.
2. Đợi xác minh capture trước khi tải trang người dùng.
3. Nhập địa chỉ HTTP hoặc HTTPS, tên miền, địa chỉ localhost hoặc từ khóa trên trang Tab mới cục bộ.
4. Xác nhận địa chỉ hoặc tìm kiếm.
5. Dùng Quay lại, Tiến tới và Tải lại khi cần.

Từ khóa được gửi tới Google. Website bạn mở nhận các yêu cầu mạng thông thường. Trình đọc tài liệu cục bộ không cần các kết nối này.

### Tab, lối tắt và zoom

- Dùng Ctrl+T để mở tab.
- Dùng Ctrl+W trong trình duyệt để đóng tab hiện tại.
- Dùng Ctrl+Tab hoặc Ctrl+Shift+Tab để chuyển tab.
- Có thể mở tối đa tám tab.
- Các tab dùng chung hồ sơ đăng nhập cục bộ.
- Mỗi tab giữ lịch sử điều hướng và zoom riêng trong phiên.
- Tối đa mười lối tắt website được lưu cục bộ.
- Tab đang mở không được khôi phục ở lần chạy tiếp theo.
- Đóng tab cuối cùng sẽ tắt trình duyệt.

Tab mới phải qua xác minh capture. Tab nền nhận yêu cầu tạm ngưng. Trang hoặc bộ máy trình duyệt vẫn có thể tiếp tục một số hoạt động dù đã có yêu cầu đó.

Nếu bật trình duyệt khi đang chiếu, QuietShare giữ khung hình công khai gần nhất trong lúc xác minh. Thời gian này có thể tới khoảng năm giây. Thất bại hoặc hủy sẽ dừng chiếu. Kiểm tra kết quả trình chiếu trước khi tiếp tục.

### Giải phóng RAM của tab nền

1. Mở menu thêm của Trình duyệt, chọn **Cho tab nền nghỉ sâu để giải phóng RAM**.
2. Lưu nội dung ô nhập chưa gửi trước. Xác nhận cảnh báo để bỏ phần trang đang chạy của các tab nền đủ điều kiện.
3. Tab đang xem, tab phát âm thanh và tab được cấp micro/camera sẽ được giữ.
4. Tab nghỉ sâu giữ địa chỉ, tiêu đề và zoom trong phiên này. Chọn lại để tải trang và xác minh capture mới trước khi hiển thị. Ô nhập chưa gửi, vị trí cuộn và lịch sử điều hướng của trang có thể mất.
5. Thao tác này do bạn chủ động chọn. Tắt trình duyệt để giải phóng toàn bộ phần web. Mức bộ nhớ vẫn tùy website.

### Khi trang hoặc tiến trình web gặp lỗi

Sự kiện GPU, tiện ích hoặc khung con có thể phục hồi sẽ giữ controller đã xác minh. Với trang chưa phản hồi, có thể đợi hoặc tải lại. Quy tắc này không bỏ qua lỗi WGC, màn hình hoặc bảo vệ thực tế.

1. Khi trang dừng, đọc mã **QS-B** và mở **Chẩn đoán**. Tab và địa chỉ hiện tại vẫn giữ trong phiên.
2. Với **QS-B001** hoặc **QS-B002**, chọn **Khôi phục tab**. Tiến trình web thoát có thể cần đợi ít giây rồi thử lại.
3. QuietShare tạo lại controller/môi trường cần thiết và kiểm tra vùng render đang gắn vào cửa sổ trước khi hiện trang.
4. Nếu nội dung riêng bị khóa, đọc bản ghi **QS-P** riêng, khắc phục nguyên nhân rồi nhấn F9. Nếu vẫn không xác minh được, giữ khóa và mở lại QuietShare.
5. Chỉ chủ động nhấn F10 sau khi bảo vệ thành công. Kiểm tra lại đúng đầu nhận.

Sự kiện tiến trình web và lỗi chiếu là hai bản ghi riêng. So thời gian UTC trước khi kết luận nguyên nhân. Một sự kiện không tự chứng minh website cụ thể gây lỗi bảo vệ. Threads đã đăng nhập và HDMI/máy chiếu cần được thử trên đúng thiết bị gặp lỗi.

### Dán ảnh vào ô soạn web

1. Sao chép ảnh raster vào clipboard Windows.
2. Mở ô soạn tương thích trên website cần dùng.
3. Nhấp vào ô soạn để nó nhận phím.
4. Tự nhấn Ctrl+V.
5. Kiểm tra ảnh xem trước của website trước khi gửi nội dung.

Khả năng tương thích tùy ô soạn của website. Đọc clipboard tự động bị từ chối. Chỉ sao chép URL ảnh hoặc tham chiếu file không giống sao chép dữ liệu điểm ảnh.

### Giới hạn và quyền thiết bị

Trình duyệt nhúng chặn hộp chọn file web native, thả file, tải xuống, chia sẻ màn hình, thông báo, DevTools và menu native. Luồng đăng nhập cần popup riêng có thể không hoạt động.

Camera và micro mặc định tắt. Khi bật tùy chọn thiết bị, quyền native vẫn yêu cầu:

- Tab đang hiển thị và hoạt động.
- Trang đã được xác minh capture.
- HTTPS.
- Yêu cầu cùng origin với trang chính.
- Windows cho phép dùng thiết bị.

Quyền thiết bị của website không được lưu. Thu hồi quyền có thể tải lại tab để dừng luồng thiết bị. Dùng ứng dụng họp thông thường khi cần chia sẻ màn hình công khai trong cuộc họp.

## 9. Hiểu bảo vệ trước khi chia sẻ

QuietShare phân biệt yêu cầu loại trừ Windows, xác minh WGC cục bộ và hình ảnh người xem thực sự nhận được. Duy trì ba kiểm tra riêng trong suốt buổi trình bày.

### Ý nghĩa từng trạng thái

- **Windows đã nhận loại trừ capture:** Windows đọc lại đúng yêu cầu loại trừ cho cửa sổ riêng.
- **WGC đã xác minh:** kiểm tra cục bộ thấy hành vi loại trừ như mong đợi bằng marker tổng hợp trên đường thu đã chọn.
- **Người xem hoặc đầu nhận vật lý chưa được xác minh:** ứng dụng chưa chứng minh hình ảnh thực tế phía người xem. Bạn cần tự quan sát đầu nhận.
- **Bị khóa hoặc xác minh thất bại:** nội dung riêng bị ẩn vì điều kiện bắt buộc chưa đạt.

Windows nhận yêu cầu không phải bảo đảm an toàn chung. WGC đạt cục bộ không chứng nhận mọi phương thức capture của ứng dụng họp, capture card hoặc nguồn OBS.

### Chuẩn bị bề mặt công khai và riêng

1. Mở slide, tài liệu hoặc trình duyệt công khai trong ứng dụng riêng.
2. Giữ trọn cửa sổ điều khiển QuietShare trên màn nguồn.
3. Với Smart Mirror, chọn màn riêng cho người xem trong Extend và cùng GPU.
4. Chạy F9 rồi đọc kết quả.
5. Bấm F10, chọn nguồn và màn đích, rồi bấm **Chia sẻ**.
6. Quan sát đầu nhận với tài liệu thử không nhạy cảm.
7. Chỉ mở lời nhắc riêng sau khi các kiểm tra cần thiết đạt.

Giữ QuietShare trên màn điều khiển. Ở chế độ **Màn hình**, đó là màn được chia sẻ. Ở chế độ **Ứng dụng** hoặc **Tab web**, đầu ra chỉ có cửa sổ hoặc trang đã chọn. Tệp trong trình đọc vẫn ở chế độ riêng tư.

### Những điều kiện gây dừng bảo vệ

Duplicate, mất loại trừ, cấu hình màn không hợp lệ, lỗi thu hoặc dựng hình, ngủ máy và bề mặt riêng không còn an toàn có thể dừng chiếu và khóa nội dung.

Dừng ngoài dự kiến có thể đổi tiêu đề và trạng thái, nháy taskbar và phát âm báo Windows. Ứng dụng không giành focus hoặc mở lại cửa sổ điều khiển đang thu nhỏ. Đọc lý do tại **Cài đặt > Trình chiếu**.

Đầu ra không tự chạy lại sau khi dừng bảo vệ. Sửa điều kiện, xác minh lại và chủ động mở phiên mới. Có thể thu nhỏ cửa sổ điều khiển khi đang chiếu. Trong phiên hoạt động, QuietShare giữ cửa sổ trong vùng làm việc nguồn đã xác minh.

QuietShare không tự đổi chế độ màn Windows. Ứng dụng cũng không ngăn được máy ảnh bên ngoài chụp màn laptop.

## 10. Chiếu qua HDMI hoặc màn hình có dây

Dùng quy trình này cho máy chiếu, TV hoặc màn hình qua HDMI, DisplayPort hay dock. Windows trước tiên phải nhận được màn hình thứ hai có thể dùng.

### Kết nối và nhận diện

1. Lưu công việc và đóng nội dung riêng.
2. Cắm dây màn hình.
3. Chọn đúng đầu vào trên máy chiếu hoặc màn hình.
4. Mở cài đặt màn hình Windows và xác nhận có màn thứ hai.
5. Nhấn Win+P rồi chọn **Extend**.
6. Nhận diện hình chữ nhật nào là laptop, hình nào là màn của người xem.

Nếu Windows chưa nhận màn, xử lý đầu vào, nguồn điện, dây, cổng hoặc driver trước khi chạy QuietShare. TV không dây từng chạy được không chứng minh đầu ra có dây dùng cùng GPU hoặc đường driver.

### Chọn và kiểm tra trong QuietShare

1. Giữ trọn cửa sổ điều khiển trên màn laptop.
2. Mở **Cài đặt > Trình chiếu**.
3. Chọn laptop làm nguồn và máy chiếu làm đích.
4. Xem nhãn vai trò và độ phân giải. Không suy ra vai trò chỉ từ số màn.
5. Đặt tài liệu mẫu công khai trên nguồn, phía sau QuietShare.
6. Nhấn F9 và đợi kết quả.
7. Nhấn F10 hoặc **Chọn nguồn**, chọn nguồn và màn đích, rồi bấm **Chia sẻ**.
8. Nhìn màn của người xem và xác nhận hiện tài liệu mẫu mà không có lời nhắc riêng.

Nếu chia sẻ thất bại, ứng dụng mở bảng Trình chiếu kèm mã. Ghi lại mã trước khi thử tiếp. Nội dung riêng biến mất cho biết cổng bảo vệ chưa đạt. Thử chia sẻ liên tục không sửa điều kiện đang lỗi.

### Một số kết quả thường gặp với HDMI

- `QS-P001`: Windows chưa cung cấp đủ hai màn cho quy trình mirror.
- `QS-P003`: ứng dụng không nhận diện được adapter của một màn.
- `QS-P004`: adapter nguồn và đích đã nhận diện khác nhau.
- `QS-P005`: cửa sổ điều khiển riêng chưa nằm trọn trên nguồn đã chọn.
- `QS-P013`: xác minh chưa chứng minh loại trừ trên đường thu được thử.

Các điều kiện này không chứng minh dây hoặc máy chiếu bị hỏng. Tra đúng mục sửa tại chương 13.

### Kết thúc

1. Dừng trình chiếu QuietShare bằng F10.
2. Dừng chia sẻ cuộc họp hoặc ghi hình trong ứng dụng tương ứng.
3. Đóng hoặc che nội dung riêng.
4. Chỉ đổi chế độ Windows hoặc rút dây sau khi kết thúc phiên.

### Bảng trình chiếu và xem trước luồng đang gửi

1. Mở **Trình chiếu** từ menu bố cục hoặc Chuyển nhanh.
2. Mở **Chọn nguồn**, rồi chọn **Màn hình**, **Ứng dụng** hoặc **Tab web**. Chọn một mục và màn **Đích**, sau đó bấm **Chia sẻ**.
3. Bấm **Đổi nguồn** trong phiên để chuyển. Bấm **Hủy** trước khi xác nhận để giữ nguồn đang phát. Để chiếu một tab khác, mở tab đó, chọn **Chia sẻ tab này** trong menu trình duyệt và xác nhận.
4. Chọn **Hướng xử lý** để đọc thao tác ứng với mã lỗi. Chức năng này giữ nguyên các kiểm tra bảo vệ và không tự bật lại đầu ra.
5. **Hiện xem trước / Ẩn xem trước** điều khiển khung xem các hình đã được QuietShare gửi thành công. Khung dùng lại tài nguyên GPU của luồng chiếu, tối đa 10 FPS. Không tạo phiên capture riêng hay lưu file ảnh.
6. Khi ẩn hoặc thu nhỏ cửa sổ, khung không tiếp tục dựng hình. Dừng chiếu, lỗi bảo vệ hoặc xác minh mới sẽ xóa hình cũ. Nếu bộ dựng xem trước lỗi, luồng chiếu công khai vẫn hoạt động độc lập và không thử lại liên tục.

Windows nhận loại trừ capture, WGC đạt xác minh và đầu nhận vật lý được xác minh là ba trạng thái riêng. Khung này cho thấy luồng QuietShare đang gửi. Nó không xác nhận hình ảnh thực tế trên máy chiếu, TV hay máy của người dự họp.

Tab có nhãn **Đang chia sẻ** tiếp tục lên màn đích khi bạn xem tab khác. Đầu ra dừng nếu tab đó bị đóng hoặc mất kết nối. Chia sẻ chỉ gửi hình ảnh.

### Tìm phần xem trước luồng đang gửi

1. Chọn **Mở xem trước** trên Home hoặc biểu tượng mắt **Xem trước** ở thanh bên.
2. Chọn màn nguồn và màn đích, thực hiện kiểm tra bảo vệ hiện có trước khi bắt đầu chiếu.
3. Xem trước hiển thị khung hình QuietShare thực sự đã gửi. Trước khi chiếu, khung có lời giải thích, không chèn luồng minh họa.
4. **Ẩn xem trước** giải phóng bộ dựng GPU và nhớ lựa chọn. Khung tĩnh báo đang tắt giúp vẫn tìm thấy mục này. Chọn **Hiện xem trước** khi muốn dùng lại bộ dựng trực tiếp.

## 11. Chiếu qua TV không dây

Hỗ trợ không dây phụ thuộc cách Windows và driver cung cấp kết nối. QuietShare không tạo liên kết không dây và không mặc định nó tương đương HDMI.

### Tạo kết nối

1. Chuẩn bị TV ở chế độ màn hình không dây mà TV hỗ trợ.
2. Dùng quy trình kết nối màn hình không dây của Windows.
3. Đợi kết nối hoàn thành.
4. Mở cài đặt màn hình Windows và xác nhận TV hiện như màn riêng.
5. Chọn **Extend**, không chọn Duplicate.
6. Nhận diện laptop và TV trước khi mở lời nhắc riêng.

Nếu đầu nhận chỉ là luồng từ xa, không xuất hiện như màn Windows riêng, nó không phải đích Smart Mirror theo quy trình này.

### Bật phiên đã xác minh

1. Đặt trọn QuietShare trên màn laptop.
2. Mở **Cài đặt > Trình chiếu**.
3. Chọn laptop làm nguồn và TV làm đích.
4. Mở tài liệu mẫu công khai trên nguồn.
5. Chạy F9.
6. Bắt đầu bằng F10 nếu xác minh đạt.
7. Quan sát TV trực tiếp.

Màn không dây được cung cấp qua adapter khác có thể không được hỗ trợ. Đọc `QS-P003` hoặc `QS-P004` nếu xuất hiện. Phiên từng thành công là thông tin hữu ích, nhưng cấu hình màn hiện tại vẫn cần xác minh.

### Kết nối lại và hiệu năng

- Sau ngắt kết nối, cần chờ trình chiếu dừng.
- Kết nối lại trong Windows rồi khôi phục Extend.
- Chọn lại cặp màn hiện tại nếu định danh hoặc số màn đã đổi.
- Chạy F9 và chủ động bắt đầu lại.
- Dùng Cân bằng hoặc Tiết kiệm trước nếu tài liệu chủ yếu đứng yên.
- Độ trễ mạng và hành vi đầu nhận vẫn có thể ảnh hưởng hình chiếu.

Tăng FPS không sửa đường thu chưa xác minh. Trước tiên sửa điều kiện được báo, sau đó đánh giá chuyển động và tài nguyên.

## 12. Cuộc họp, OBS và phục hồi phiên

Dùng điều khiển của ứng dụng thực sự chia sẻ hoặc ghi hình. Nút che và dừng của QuietShare tác động QuietShare. Chúng không điều khiển luồng trực tiếp của ứng dụng khác.

### Ghi âm, chép lời và duyệt lại ngay trên máy

1. Mở **Cuộc họp** ở thanh bên. Chọn **Xuất / thêm > Kiểm tra nguồn âm thanh và nhận dạng**.
2. Trong **Cài đặt > Cuộc họp**, chọn Tiếng Việt hoặc Tiếng Anh, thư mục xuất cục bộ và có tự chép lời sau khi ghi hay không.
3. Giữ **Small · 466 MiB** mặc định để ưu tiên độ chính xác. Có thể chọn Base · 142 MiB khi cần nhẹ hơn.
4. Chọn **Cài bộ nhận dạng tùy chọn**. Chỉ thao tác chủ động này mới tải bộ CPU và mô hình đã chọn. Giữ ứng dụng mở đến khi cài xong. Mô hình nằm tại `%LOCALAPPDATA%\QuietShare\Speech`.
5. Chọn **WAV + nội dung** để giữ âm thanh hoặc **Chỉ nội dung** để xóa WAV tạm sau khi transcript được lưu thành công vào sổ. Khi đang ghi vẫn cần dung lượng tạm trên ổ đĩa.
6. Quay lại Cuộc họp và chọn **Ghi âm và chép lời cuộc họp**. Kiểm tra trạng thái đang ghi và mức âm thanh. Cho âm thanh họp phát qua thiết bị phát mặc định của Windows.
7. Chọn lại nút ghi để dừng. Nhận dạng chạy cục bộ ở nền. **Dừng xử lý** dừng chép lời hoặc cài mô hình và giữ bản ghi.
8. Duyệt các đoạn có mốc giờ trong Cuộc họp. Chọn đoạn để sửa nội dung, người nói và giờ đầu/cuối. Dùng **Lưu đoạn** hoặc Ctrl+S. Thay đổi cũng được lưu sau một khoảng nghỉ ngắn.
9. Tự đánh dấu **Quyết định** và **Việc cần làm** thực sự có trong cuộc họp. Dùng bộ lọc và ô tìm kiếm. QuietShare không tự bịa tóm tắt hoặc nhận tên người từ âm thanh trộn.
10. Mở **Xuất / thêm** và chọn TXT, VTT có thời gian hoặc biên bản Markdown. File xuất nằm ngay trong thư mục đã chọn. **Mở file vừa xuất trong QuietShare** giúp xem kết quả.
11. Chỉ chọn **Thêm transcript vào lời nhắc** khi muốn đưa ghi chép đã duyệt sang lời nhắc. Nhập transcript và nhận dạng âm thanh không tự thay lời nhắc.

Small là mô hình Whisper đa ngôn ngữ, không bảo đảm mọi từ đều đúng. Trên CPU nhỏ, chép lời có thể lâu hơn thời lượng bản ghi. QuietShare giới hạn hai luồng CPU nền và mức trần 2 GiB bộ nhớ cho tiến trình con. Khi rảnh ứng dụng không chạy nhận dạng. Nút dừng kết thúc đúng tiến trình xử lý của ứng dụng. Windows Speech API vẫn là phương án dự phòng khi máy có bộ nhận dạng đúng ngôn ngữ và chưa cài Whisper tùy chọn.

### Giữ người nói từ nền tảng họp và khôi phục ghi chép

1. Xuất transcript VTT hoặc TXT từ Teams, Zoom hoặc Google Meet bằng công cụ của nền tảng đó.
2. Chọn đúng **Nền tảng cuộc họp** trong Cài đặt > Cuộc họp.
3. Chọn **Cuộc họp > Xuất / thêm > Nhập transcript Teams / Zoom / Meet**.
4. Kiểm tra tên và mốc giờ. Dòng VTT `<v Speaker>` được giữ lại. Tiền tố tên thông thường chỉ được đọc khi đã chọn nền tảng cụ thể. Bản nhận dạng từ âm thanh Whisper để bạn tự gán tên.
5. Ở cửa sổ nhỏ, dùng **Các đoạn**, **Nội dung** và **Người / giờ** để chuyển vùng. Cửa sổ rộng hiện danh sách cùng vùng sửa.
6. Chỉ xuất VTT sau khi mọi đoạn có nội dung đều có giờ hợp lệ. Ghi chú thủ công chưa có giờ vẫn xuất TXT hoặc biên bản được.

Sổ ghi chép được mã hóa cho tài khoản Windows tại `meeting-notes.dpapi`. Khi nhập, một bản trước đó được giữ tại `meeting-notes-before-import.dpapi`. Hãy xuất các phiên quan trọng trước khi nhập phiên khác. File xuất và WAV là file cục bộ đọc bình thường. Quy trình này không bật API nền tảng, OAuth, thu micro hoặc tải âm thanh lên mạng. Đổi thiết bị phát có thể kết thúc một WAV chưa đủ phiên. Đóng QuietShare sẽ dừng ghi và xử lý.

### Mã trạng thái chép lời cuộc họp

| Mã | Ý nghĩa | Cách xử lý |
|---|---|---|
| `QS-R001` | Không tìm thấy WAV | Ghi một phiên mới. |
| `QS-R002` | Windows Speech API không khởi động được | Mở lại QuietShare hoặc cài Whisper tùy chọn. |
| `QS-R003` | WAV không được hỗ trợ | Ghi lại từ thiết bị phát mặc định. |
| `QS-R004` | Thiếu bộ nhận dạng đúng ngôn ngữ | Cài Whisper cục bộ hoặc bộ nhận dạng Windows tương ứng. |
| `QS-R005` | Không có kết quả nhận dạng dùng được | Kiểm tra âm thanh đang phát và ngôn ngữ đã chọn. |
| `QS-R006` | Đã dừng xử lý | Bản ghi gốc được giữ lại. Ghi phiên mới khi sẵn sàng. |
| `QS-R007` | Không lưu được transcript | Kiểm tra quyền ghi và dung lượng thư mục cục bộ. |
| `QS-R008` | Cài đặt hoặc kiểm tra toàn vẹn thất bại | Kiểm tra mạng/dung lượng rồi cài hoặc sửa Whisper. |
| `QS-R009` | Mô hình cục bộ xử lý thất bại | Giải phóng RAM rồi thử bản ghi ngắn hơn. Giữ WAV. |

### Zoom, Meet hoặc Teams với một màn

1. Mở tài liệu công khai trong cửa sổ ứng dụng riêng.
2. Dùng QuietShare làm trình đọc riêng.
3. Chạy F9. Xác minh WGC hỗ trợ một màn dù Smart Mirror cần hai màn.
4. Trong ứng dụng họp, chọn chia sẻ cửa sổ ứng dụng công khai gốc.
5. Không chọn cửa sổ QuietShare riêng.
6. Quan sát đầu nhận cuộc họp trên thiết bị khác bằng tài liệu mẫu không nhạy cảm.
7. Chỉ tiếp tục khi đầu nhận có đúng tài liệu công khai và không có lời nhắc riêng.
8. Kết thúc bằng nút dừng chia sẻ của ứng dụng họp.

Nếu nội dung riêng xuất hiện, dừng chia sẻ cuộc họp ngay. Kiểm tra cục bộ đạt không chứng minh ứng dụng họp dùng cùng phương pháp thu hình.

### Vừa họp trực tuyến vừa dùng máy chiếu

1. Hoàn thành chương 10 hoặc 11 cho màn vật lý.
2. Ưu tiên cửa sổ ứng dụng công khai gốc làm nguồn cuộc họp trực tuyến.
3. Kiểm tra cả đầu nhận vật lý lẫn đầu nhận cuộc họp bằng nội dung mẫu.
4. Kiểm tra lại sau khi đổi chế độ màn hoặc nguồn capture của cuộc họp.
5. Dừng cả chia sẻ cuộc họp và trình chiếu QuietShare khi kết thúc.

Cửa sổ đầu ra Smart Mirror cũng yêu cầu loại trừ capture. Thu màn đích có thể bỏ qua đầu ra đó hoặc hiện vùng trống. Chia sẻ cửa sổ công khai gốc giúp tránh phụ thuộc vào việc thu cửa sổ đầu ra đang được loại trừ.

### Ghi hoặc phát trực tiếp bằng OBS

1. Tạo nguồn OBS cho ứng dụng công khai gốc.
2. Ưu tiên Window Capture khi phù hợp với ứng dụng đó.
3. Nếu dùng Display Capture, chọn đúng màn công khai và lưu ý các cửa sổ đầu ra bị loại trừ.
4. Không chọn cửa sổ QuietShare riêng làm nguồn OBS.
5. Ghi thử một đoạn ngắn không chứa thông tin bí mật.
6. Phát lại và xem nội dung thực sự được ghi.
7. Kiểm tra lại sau khi đổi nguồn, backend capture hoặc bố trí màn hình.
8. Dừng ghi hoặc phát trong OBS khi kết thúc.

WGC đạt không chứng nhận mọi backend capture của OBS. Capture card hoặc thiết bị ghi bên ngoài có thể đi theo đường khác nữa.

### Duplicate và phục hồi

Duplicate không hỗ trợ thuyết trình có nội dung riêng. QuietShare khóa khi phát hiện nhân đôi màn. Nếu cần hiện cùng tài liệu công khai, đóng lời nhắc riêng và dùng ứng dụng công khai trực tiếp.

Sau Duplicate về Extend, cắm lại dây, ngủ máy hoặc GPU reset:

1. Khôi phục Extend trong Windows.
2. Đợi đủ màn cần dùng xuất hiện.
3. Đưa trọn QuietShare lên nguồn cần dùng.
4. Chọn nguồn và đích hiện tại.
5. Chạy F9 rồi đọc kết quả.
6. Chủ động bắt đầu chiếu bằng F10.
7. Kiểm tra lại mọi đầu nhận cần dùng.

Nếu Play không hiện gì và nội dung riêng bị ẩn, đọc mã trong **Cài đặt > Trình chiếu**. Không bỏ kiểm tra bảo vệ. Chương 13 có các bước sửa theo thứ tự.

## 13. Danh mục mã lỗi trình chiếu

Mã cho biết điều kiện phát hiện. Chúng không tự kết luận phần cứng hỏng. Lý do nội bộ hiện cạnh mã ổn định để hỗ trợ kỹ thuật.

Sau khi sửa, xác minh lại và quan sát đầu nhận bằng nội dung không nhạy cảm. Nếu điều kiện vẫn còn, giữ lời nhắc riêng đóng và giữ bản ghi chẩn đoán theo chương 14.

### QS-P001 `need-two-monitors`

**Điều kiện:** Smart Mirror nhận ít hơn hai màn.

1. Kết nối, bật đầu nhận và chọn đúng đầu vào.
2. Xác nhận cài đặt màn Windows hiện hai màn riêng.
3. Chọn Extend rồi chọn lại nguồn và đích trong QuietShare.

Đọc trên một màn và xác minh WGC cục bộ không bắt buộc Smart Mirror.

### QS-P002 `same-monitor`

**Điều kiện:** Nguồn và đích là cùng một màn.

1. Nhận diện laptop và đầu nhận trong cài đặt màn Windows.
2. Chọn hai màn khác nhau làm nguồn và đích.
3. Giữ QuietShare trên nguồn, chạy F9 rồi F10.

### QS-P003 `adapter-unknown`

**Điều kiện:** QuietShare không nhận diện được adapter GPU của một màn đã chọn.

1. Chờ kết nối màn hoàn thành rồi chọn lại màn.
2. Kiểm tra driver đồ họa và adapter màn của laptop. Kết nối lại đầu nhận nếu cần.
3. Mở lại QuietShare rồi thử. Nếu vẫn không nhận diện được, gửi mã và kiểu kết nối.

Mã này chưa xác lập rằng hai màn dùng hai GPU khác nhau.

### QS-P004 `different-adapters`

**Điều kiện:** Nguồn và đích đã nhận diện thuộc hai adapter GPU khác nhau. Chưa hỗ trợ sao chép giữa adapter.

1. Xem GPU điều khiển từng màn trong thông tin hiển thị của laptop hoặc nhà sản xuất đồ họa.
2. Nếu phần cứng hỗ trợ, dùng cổng hoặc cấu hình mà cả hai màn được một adapter điều khiển.
3. Nếu không có cấu hình cùng adapter phù hợp, dùng ứng dụng công khai trực tiếp, không dùng lời nhắc riêng theo quy trình chiếu này.

Ưu tiên đồ họa trong Windows không bảo đảm đổi GPU nối vật lý với cổng xuất hình.

### QS-P005 `control-location`

**Điều kiện:** Cửa sổ điều khiển riêng không nằm trọn trong màn nguồn đã chọn.

1. Đưa toàn bộ cửa sổ QuietShare lên nguồn đã chọn.
2. Khôi phục hoặc giảm kích thước nếu cửa sổ vắt qua hai màn.
3. Kiểm tra nguồn được chọn rồi xác minh lại.

### QS-P006 `windows-unsupported`

**Điều kiện:** Windows dưới build 19041.

1. Xem phiên bản và build Windows.
2. Cập nhật Windows được hỗ trợ, phù hợp quy định của tổ chức.
3. Mở lại QuietShare rồi xác minh.

### QS-P007 `dwm-unavailable`

**Điều kiện:** Bộ dựng desktop không khả dụng cho quy trình thu hình bắt buộc.

1. Trở về phiên desktop Windows bình thường.
2. Kiểm tra driver đồ họa và khả năng dựng desktop.
3. Khởi động lại Windows nếu cần, sau đó mở QuietShare và thử.

### QS-P008 `control-affinity`

**Điều kiện:** Không nhận hoặc không giữ được loại trừ capture của cửa sổ riêng.

1. Đóng rồi mở lại QuietShare.
2. Xác nhận Windows được hỗ trợ và driver đồ họa hoạt động.
3. Chạy F9. Giữ nội dung riêng đóng nếu vẫn không nhận loại trừ.

### QS-P009 `private-popup-affinity`

**Điều kiện:** Hộp thoại hoặc popup riêng thiếu loại trừ capture bắt buộc.

1. Đóng hộp thoại và menu riêng.
2. Trở về cửa sổ điều khiển rồi xác minh lại.
3. Nếu cùng thao tác gây lặp lại, gửi thao tác mở popup, không gửi nội dung riêng trong đó.

### QS-P010 `topology-unavailable`

**Điều kiện:** Không đọc được cấu hình màn Windows.

1. Chờ kết nối, gắn dock hoặc đổi chế độ màn hoàn thành.
2. Xác nhận Extend trong Windows và chọn lại các màn hiện tại.
3. Kiểm tra driver hoặc khởi động Windows lại nếu vẫn còn điều kiện lỗi.

### QS-P011 `display-cloned`

**Điều kiện:** Phát hiện Duplicate hoặc nhân đôi màn.

1. Đóng hoặc che nội dung riêng.
2. Nhấn Win+P rồi chọn Extend.
3. Chọn lại cặp màn, chạy F9 và chủ động bật bằng F10.

Nếu phải giữ Duplicate, dùng tài liệu công khai trực tiếp mà không mở lời nhắc riêng.

### QS-P012 `capture-frame`

**Điều kiện:** Khởi tạo, thiết lập hoặc lấy khung hình capture thất bại.

1. Khôi phục desktop nguồn sau ngủ máy, ngắt kết nối hoặc chuyển trạng thái đồ họa.
2. Mở lại QuietShare, chọn nguồn rồi xác minh lại.
3. Nếu lặp lại, kiểm tra driver đồ họa và kèm HRESULT được ghi khi báo lỗi.

### QS-P013 `canary-failed`

**Điều kiện:** Marker xác minh tổng hợp chưa chứng minh loại trừ capture trên đường được thử.

1. Đóng hộp thoại riêng đang phủ và hoàn thành các thay đổi màn.
2. Giữ QuietShare trên nguồn đã chọn rồi chạy F9 lại.
3. Nếu vẫn thất bại, giữ lời nhắc bị khóa và gửi mã cùng phiên bản ứng dụng.

Windows nhận loại trừ không thay thế được kết quả xác minh thất bại này.

### QS-P014 `render-frame`

**Điều kiện:** Không tạo hoặc dựng đúng đầu ra D3D11 cho người xem.

1. Xác nhận màn đích vẫn kết nối và sẵn sàng.
2. Chọn lại nguồn và đích, xác minh rồi thử.
3. Mở lại QuietShare và kiểm tra driver đồ họa nếu vẫn lỗi.

### QS-P015 `display-topology`

**Điều kiện:** Cấu hình màn hoặc capture đã chọn thay đổi.

1. Khôi phục cấu hình Extend cần dùng.
2. Chọn nguồn và đích hiện tại, không dựa vào số màn cũ.
3. Chạy F9, bật F10 và xem đầu nhận.

### QS-P016 `device-removed`

**Điều kiện:** Thiết bị GPU dùng capture không còn khả dụng hoặc đã reset.

1. Lưu công việc và khôi phục các màn cần dùng.
2. Đóng rồi mở lại QuietShare, sau đó xác minh lại.
3. Nếu lặp lại, kiểm tra driver đồ họa và gửi HRESULT cùng thao tác ngay trước lỗi.

### QS-P017 `projector-affinity`

**Điều kiện:** Cửa sổ đầu ra công khai mất điều kiện loại trừ capture bắt buộc.

1. Dừng phiên và giữ tài liệu riêng đóng.
2. Mở lại QuietShare, khôi phục cặp màn và xác minh.
3. Báo lỗi nếu lặp lại. Không tắt cơ chế bảo vệ để tiếp tục.

### QS-P018 `projector-closed`

**Điều kiện:** Cửa sổ đầu ra cho người xem đã bị đóng.

1. Xác nhận bạn có chủ động đóng cửa sổ không.
2. Quay về QuietShare và kiểm tra các màn đang chọn.
3. Xác minh và chủ động bắt đầu lại khi sẵn sàng mở lại đầu ra.

### QS-P019 `projector-escape`

**Điều kiện:** Phím Escape đã dừng đầu ra cho người xem.

1. Kiểm tra có chủ động nhấn phím trong cửa sổ đầu ra đó không.
2. Quay về cửa sổ điều khiển.
3. Xác minh và chủ động bắt đầu lại khi sẵn sàng.

### QS-P020 `system-suspend`

**Điều kiện:** Ngủ hoặc tạm ngưng máy đã ngắt trình chiếu.

1. Đánh thức laptop và đầu nhận.
2. Chờ màn kết nối lại rồi khôi phục Extend.
3. Chọn lại cặp màn, xác minh và chủ động mở phiên mới.

### QS-P021 `winrt-unavailable`

**Điều kiện:** Hỗ trợ capture Windows Runtime cần thiết không khả dụng.

1. Xác nhận Windows đáp ứng phiên bản được hỗ trợ.
2. Mở lại QuietShare và khởi động Windows lại nếu cần.
3. Báo lỗi nếu vẫn xảy ra trên Windows phù hợp.

### QS-P022 `privacy-unsafe`

**Điều kiện:** Một kiểm tra bảo vệ thất bại nhưng chưa ghi được lý do cụ thể hơn.

1. Kiểm tra Extend và trạng thái loại trừ capture Windows.
2. Đóng hộp thoại riêng, giữ cửa sổ điều khiển trên nguồn rồi xác minh lại.
3. Giữ lời nhắc đóng và gửi phiên bản ứng dụng nếu lỗi lặp lại.

### QS-P023 `environment-invalidated`

**Điều kiện:** Môi trường capture không còn được xác minh.

1. Khôi phục cấu hình màn cần dùng.
2. Chọn lại nguồn, đích rồi chạy F9.
3. Nếu lặp lại, ghi thao tác ngay trước khi mất xác minh rồi gửi lỗi.

### QS-P024 `source-monitor-changed`

**Điều kiện:** Màn nguồn biến mất hoặc thay đổi khi di chuyển cửa sổ điều khiển.

1. Khôi phục kết nối nguồn và Extend cần dùng.
2. Đặt toàn bộ cửa sổ điều khiển trên nguồn đó.
3. Chọn lại, xác minh và chủ động bắt đầu lại.

### QS-P000 - chưa có lý do lỗi

Đây là trạng thái chưa xác minh, không phải chẩn đoán phần cứng.

1. Chọn nguồn cần dùng.
2. Chạy F9 rồi đợi kết quả.
3. Đọc mã cụ thể xuất hiện sau đó nếu có.

### QS-P025 `window-unavailable`

Cửa sổ đã đóng, bị thu nhỏ hoặc không cấp được khung hình. Khôi phục hoặc mở lại cửa sổ, rồi vào **Chọn nguồn > Ứng dụng** để chọn lại.

### QS-P099 - lý do chưa biết

Mã dự phòng này biểu thị lý do chưa có ánh xạ công khai được nhận diện.

1. Giữ lời nhắc riêng đóng.
2. Giữ lại lý do nội bộ và phiên bản ứng dụng.
3. Gửi bản ghi theo chương 14.

### Lỗi bộ thuyết trình

### QS-W001 - Không đọc được thư viện đã lưu

Đóng QuietShare và giữ một bản sao presentations.dpapi. Khôi phục bản tốt bằng cùng tài khoản Windows. Nếu muốn tạo thư viện mới, đổi tên file cũ thành presentations-backup.dpapi trước khi mở lại. Ứng dụng giữ nguyên file không đọc được.

### QS-W002 - Tên bộ trống hoặc quá dài

Nhập tên có từ 1 đến 80 ký tự.

### QS-W003 - Tài liệu có thay đổi chưa lưu

Quay lại tài liệu và chọn Lưu hoặc Ctrl+S, sau đó lưu bộ lại. Thao tác lưu bộ không ghi đè file gốc.

### QS-W004 - Đã lưu đủ tám bộ

Xóa bộ không cần dùng hoặc nhập tên bộ có sẵn và xác nhận thay thế.

### QS-W005 - Không lưu hoặc cập nhật được thư viện

Kiểm tra dung lượng trống và quyền ghi thư mục dữ liệu QuietShare cục bộ. Giữ nguyên thư viện cũ và thử lại sau khi khắc phục.

### QS-W006 - Không tạo được bản dự phòng lời nhắc

Kiểm tra quyền truy cập và dung lượng thư mục dữ liệu cục bộ. Phiên hiện tại vẫn được giữ. Khắc phục trước khi mở bộ.

### QS-W007 - Không mở được một số đường dẫn đã lưu

Tìm lại file đã di chuyển hoặc tạm không truy cập được. Mở bằng Ctrl+O rồi lưu lại bộ đã sửa. Các tài liệu còn mở được vẫn được khôi phục.

## 14. Chẩn đoán và kiểm tra trước buổi trình bày

### Tìm bản ghi trình chiếu gần nhất

Mở **Cài đặt > Trình chiếu > Chẩn đoán lần dừng** hoặc **Cài đặt > Trình duyệt > Chẩn đoán lần dừng**. Trang Trình chiếu cũng có **Chẩn đoán**. **Sao chép báo cáo** chỉ sao chép các trường cố định đang hiện khi bạn chủ động nhấn. Trang vẫn xem được lúc nội dung riêng bị che và không tự khởi động chiếu.

Báo cáo ghép lỗi chiếu gần nhất với sự kiện tiến trình web gần nhất. Phần web có mã QS-B, UTC, loại tiến trình cố định, reason/exit dạng số và số sự kiện. File cục bộ là `browser-fault.dat`. Không có URL, tiêu đề, chữ riêng hoặc nội dung trang. Một sự kiện web có thể phục hồi vẫn có bản ghi dù trình chiếu không dừng.

Sau khi bắt đầu chiếu thất bại, xem **Cài đặt > Trình chiếu**. QuietShare tự mở nhóm này khi khởi động chiếu lỗi.

Nếu cần, mở `%LOCALAPPDATA%\QuietShare\projection-stop.json` bằng trình soạn thảo. Đây là một bản ghi lỗi cục bộ gần nhất, bị ghi đè khi có lỗi sau. Không có file không chứng minh chưa từng có lỗi. Bản cũ có thể chỉ ghi lỗi trong phiên đang chạy.

Bản ghi gồm:

- `code`: mã công khai trong sổ tay.
- `reason`: lý do kỹ thuật nội bộ.
- `version`: phiên bản ứng dụng.
- Giờ UTC: thời điểm ghi lỗi.
- `phase`: `start`, `verification` hoặc `running`.
- `hresult`: kết quả kỹ thuật đính kèm khi có.
- `sessionMs`: thời gian phiên, bằng không trước khi trình chiếu bắt đầu.
- `resourceMode`: chế độ xử lý được chọn.

`0x00000000` nghĩa là không đính kèm HRESULT thất bại. Nó không có nghĩa trình chiếu thành công. Bản ghi không chứa ảnh, chữ riêng, đường dẫn file, URL hoặc định danh màn hình. Ghi chẩn đoán thất bại không cho phép trình chiếu.

### Xuất lịch sử lỗi gần đây

1. Mở **Chẩn đoán lần dừng** từ Cài đặt > Trình chiếu hoặc Trình duyệt.
2. Chọn **Xuất lịch sử lỗi** (JSON), hoặc nhấn Ctrl+S tại trang này. Có thể xuất ngay cả khi nội dung riêng đang bị che.
3. File mới nằm trong **Downloads / QuietShare-Diagnostics**. Muốn đổi nơi lưu, chọn thư mục cục bộ có sẵn tại **Cài đặt > Dữ liệu > Thư mục xuất** trước khi xuất.
4. Gửi JSON kèm các bước gây lỗi. QuietShare không tự tải báo cáo lên mạng.

Nhật ký cục bộ `error-history.dat` giữ 100 sự kiện có mã gần nhất qua các lần khởi động, tối đa 7.612 byte. Mỗi mục có UTC, phiên bản, mã QS, giai đoạn, chi tiết dạng số và HRESULT hoặc mã thoát tiến trình web. File xuất thêm bản Windows, trạng thái màn hình/bảo vệ, chế độ tài nguyên, số tab và bộ nhớ riêng hiện tại kèm cờ đo đủ hay thiếu. Các giá trị này phản ánh máy tại lúc xuất. Không suy diễn rằng đầu nhận đã được xác minh.

Nhật ký không chứa lời nhắc, đường dẫn file, URL, tên tab, âm thanh hoặc ảnh chụp. Đây là báo cáo trường cố định, không phải bản dump khi crash. Bắt đầu thu từ v0.23.0, không dựng lại lỗi đã xảy ra trước đó. Lỗi chưa có mã hoặc không ghi được có thể vắng mặt.

| Mã | Cách xử lý |
|---|---|
| `QS-D004` | Dựng PDF chạm giới hạn RAM/thời gian. Giảm zoom hoặc đóng PDF khác rồi thử lại. Trang quá phức tạp có thể cần bản đơn giản hơn. |
| `QS-D005` | Không tải được trang PDF hoặc bitmap. Mở lại file và kiểm tra bằng trình đọc khác. Giữ file gốc. |
| `QS-F001` | File, đường dẫn hoặc định dạng bị từ chối. Kiểm tra giới hạn ở chương 4 rồi mở bản cục bộ được hỗ trợ. |
| `QS-F002` | Không lưu được file. Giữ bản nháp, kiểm tra quyền ghi, dung lượng và thay đổi từ ứng dụng khác trước khi thử lại. |
| `QS-F003` | Trình xem không mở được file. Kiểm tra file hợp lệ, được hỗ trợ và không có mật khẩu. |
| `QS-J001` | Không đọc được lịch sử. Đóng QuietShare, sao lưu error-history.dat. Khôi phục bản tốt hoặc đổi tên file trước khi mở lại để tạo nhật ký mới. Ứng dụng giữ file lỗi. |
| `QS-J002` | Có sự kiện chưa lưu được. Kiểm tra quyền ghi và dung lượng thư mục dữ liệu cục bộ. Không dựng lại được sự kiện đã mất. |
| `QS-J003` | Xuất JSON hoặc lưu thư mục thất bại. Chọn thư mục cục bộ có sẵn, có quyền ghi, kiểm tra dung lượng rồi thử lại. |

### Báo lỗi có thể lặp lại

1. Ghi phiên bản ứng dụng trên Home.
2. Sao chép mã chính xác và lý do nội bộ.
3. Kèm phase và HRESULT nếu có.
4. Nêu phiên bản Windows và kiểu kết nối như HDMI, không dây hoặc dock.
5. Nêu Windows có nhận đầu nhận không và đang Extend hay Duplicate.
6. Liệt kê thao tác ngay trước lỗi cùng kết quả mong đợi.
7. Xem lại bản ghi nhỏ hoặc cắt ảnh về vùng trạng thái trước khi chia sẻ.

Không gửi lời nhắc riêng, thông tin đăng nhập hoặc nội dung tài liệu cá nhân để minh họa lỗi. Mã trên laptop bị ảnh hưởng hữu ích hơn nhật ký không liên quan từ máy khác.

### Một số sự cố khác

- **Không mở được file:** kiểm tra đường dẫn cục bộ, định dạng và dung lượng ở chương 4. PDF có mật khẩu hoặc mã hóa không hỗ trợ cần một bản tương thích.
- **Không lưu được:** kiểm tra file có bị ứng dụng khác thay đổi không. Giữ bản nháp trước khi tải lại.
- **Không dùng được trình duyệt:** cài hoặc cập nhật [WebView2 Runtime](https://developer.microsoft.com/en-us/microsoft-edge/webview2/) chính thức, rồi tắt và bật lại trình duyệt.
- **Không dán được ảnh:** chọn ô soạn website tương thích rồi tự nhấn Ctrl+V với dữ liệu ảnh raster trong clipboard. Hộp tải file web vẫn bị chặn.
- **Chữ nhạt:** dùng độ mờ 100%, theme phù hợp, chữ lớn hơn và độ đậm được hỗ trợ.
- **Phím tắt không chạy:** kiểm tra trang hoạt động, focus bàn phím và xung đột đăng ký toàn hệ thống.

### Trước mỗi buổi trình bày

1. Lưu công việc và kết nối đầu nhận cần dùng.
2. Xác nhận Extend và đúng nguồn, đích nếu dùng Smart Mirror.
3. Xác nhận toàn bộ cửa sổ riêng nằm trên nguồn.
4. Chạy xác minh WGC.
5. Kiểm tra đầu nhận hoặc bản ghi thử bằng tài liệu không nhạy cảm.
6. Kiểm tra F8 để che và nút dừng riêng của từng ứng dụng chia sẻ.

Sau khi đổi màn hoặc đường capture, lặp lại xác minh và quan sát đầu nhận. Phần mềm không bảo đảm chống mọi lỗi hệ điều hành, driver, phương pháp thu hình hoặc máy ảnh bên ngoài.

Lời nhắc và lịch sử gần đây được Windows DPAPI mã hóa cho người dùng cục bộ. Cấu hình và bố cục lưu trên máy. Cookie và đăng nhập trình duyệt dùng hồ sơ WebView2 cục bộ riêng. Đây là các cơ chế lưu trữ khác nhau. Gỡ ứng dụng vẫn giữ lời nhắc đã lưu.

Lý do lỗi trình chiếu mới cần có mã ổn định và các bước phục hồi theo thứ tự trong cả hai ấn bản trước khi phát hành. Danh mục dành cho điều kiện trình chiếu đã hiện thực. Không gán mã giả cho lỗi website hoặc file không liên quan.

[Tải bản phát hành](https://github.com/TDUmii/QuietShare/releases/latest) | [Mục lục tài liệu](README.md) | [Chi tiết quyền riêng tư](PRIVACY.md) | [Xử lý sự cố](TROUBLESHOOTING.md)

### Mã phục hồi trình đọc và sổ ghi chép

| Mã | Cách xử lý |
|---|---|
| `QS-W008` | Không lưu được lựa chọn xem trước. Kiểm tra quyền ghi thư mục dữ liệu. Lựa chọn vẫn áp dụng trong phiên hiện tại. |
| `QS-D001` | Không đọc được dữ liệu đọc. Đóng QuietShare, sao lưu reading.dpapi rồi khôi phục bản tốt bằng cùng tài khoản Windows hoặc đổi tên file để tạo mới. |
| `QS-D002` | Không lưu được dữ liệu đọc hoặc đã đủ 64 dấu trang. Kiểm tra quyền ghi/dung lượng hoặc bỏ dấu trang không cần. |
| `QS-D003` | Số trang nằm ngoài PDF. Nhập số nguyên từ 1 đến tổng số trang đang hiện. |
| `QS-N001` | Không đọc được ghi chép cũ. Đóng QuietShare và sao lưu meeting-notes.dpapi. Khôi phục bản tốt bằng cùng tài khoản hoặc đổi tên file trước khi tạo sổ mới. |
| `QS-N002` | Giờ của đoạn không hợp lệ. Dùng HH:MM:SS.mmm với giờ cuối sau giờ đầu hoặc để trống cả hai ô. |
| `QS-N003` | VTT cần thời gian hợp lệ cho mọi đoạn có nội dung. Nhập giờ hoặc xuất TXT. |
| `QS-N004` | Transcript không đúng định dạng hoặc vượt giới hạn. Dùng VTT/TXT UTF-8, tối đa 10.000 đoạn, 32.000 ký tự mỗi đoạn và khoảng 2 triệu ký tự tổng. |
| `QS-N005` | Không tạo dự phòng/lưu/xuất được ghi chép. Kiểm tra thư mục xuất cục bộ, quyền ghi và dung lượng. Giữ bản cũ rồi thử lại. |

Dùng **Ẩn xem trước** tại Trình chiếu hoặc **Cài đặt > Trình chiếu > Xem trước luồng đang gửi** để tắt xem trước. Lựa chọn được nhớ qua lần mở lại. Tắt sẽ giải phóng bộ dựng GPU và ngừng vẽ xem trước. Trình chiếu vẫn tiếp tục. Bật lại chỉ tạo vùng xem trước khi đang hiện vùng đó. Đây là luồng đang gửi, không phải xác nhận đầu nhận vật lý.


### Mã phục hồi tiến trình trình duyệt

| Mã | Sự kiện phát hiện và cách xử lý |
|---|---|
| `QS-B001` | Tiến trình trình duyệt đã thoát. Đợi thoát xong rồi Khôi phục tab. Tab vẫn giữ trong phiên. |
| `QS-B002` | Tiến trình render chính đã thoát. Khôi phục tab để tạo và xác minh lại. |
| `QS-B003` | Trang chưa phản hồi. Đợi hoặc tải lại. Có thể đóng tab nặng không dùng. |
| `QS-B004` | Render khung con thoát. Controller được giữ. Tải lại nếu khung vẫn trắng. |
| `QS-B005` | Tiến trình tiện ích thoát. WebView2 có thể phục hồi. Tải lại nếu chức năng trang vẫn lỗi. |
| `QS-B006` | Tiến trình hỗ trợ sandbox thoát. Đợi phục hồi rồi tải lại nếu cần. |
| `QS-B007` | Tiến trình GPU thoát. WebView2 có thể tạo lại. Nếu lặp lại, cập nhật driver đồ họa và runtime. |
| `QS-B008` | Tiến trình plugin thoát. Tải lại trang. Một số chức năng cũ có thể không được hỗ trợ. |
| `QS-B009` | Tiến trình môi giới plugin thoát. Tải lại trang và cập nhật WebView2 nếu lặp lại. |
| `QS-B010` | Tiến trình WebView2 khác thoát. Kiểm tra trang và tải lại nếu cần. |
| `QS-B011` | Bộ nhớ cam kết Windows gần hết. QuietShare tạm yêu cầu mức bộ nhớ thấp hơn và ngừng tạo thêm tab. Lưu ô nhập, cho tab nền nghỉ sâu hoặc đóng ứng dụng không dùng. Thử lại khi có đủ khoảng trống bộ nhớ. |
| `QS-B099` | Sự kiện tiến trình chưa nhận dạng. Tải lại để tạo và xác minh. Giữ mã reason/exit dạng số. |

QS-B001 đến QS-B010 và QS-B099 mô tả thông báo tiến trình. Một lỗi GPU dùng chung có thể báo cho nhiều tab, nên số thông báo không phải số lần crash riêng biệt. Lý do renderer `5` nghĩa là hết bộ nhớ. QS-B011 cảnh báo bộ nhớ cam kết Windows. Lỗi bảo vệ độc lập vẫn khóa nội dung riêng.

### Mã phục hồi hồ sơ sử dụng

- **QS-W009:** không đọc được hồ sơ cũ. Đóng QuietShare và sao lưu `workspace-profiles.dpapi`. Khôi phục bản tốt bằng cùng tài khoản Windows hoặc đổi tên file trước khi tạo mới. File lỗi được giữ nguyên.
- **QS-W010:** không lưu được hồ sơ hoặc màu. Kiểm tra quyền ghi và dung lượng trống. Giữ hồ sơ cũ rồi thử lại.

### Feed đứng nhưng nút của ứng dụng vẫn bấm được

1. Mở **Chẩn đoán**, đọc đúng mã QS-B và reason. **QS-B002** hoặc **QS-B004** với reason `5` là renderer hết bộ nhớ. **QS-B003** là trang không phản hồi.
2. So **bộ nhớ cam kết còn trống** với **RAM vật lý còn trống**. Máy có thể còn RAM vật lý nhưng giới hạn bộ nhớ cam kết đã gần hết.
3. Khi có **QS-B011**, QuietShare yêu cầu mức bộ nhớ thấp hơn cho trang đang xem chưa bị tạm ngưng, đồng thời chặn mở thêm tab. Trang hiện tại và ô nhập được giữ. Mức bình thường trở lại khi có đủ khoảng trống. Giảm bộ nhớ phụ thuộc runtime và có thể tạm giảm hiệu năng.
4. Lưu ô nhập nếu còn thao tác được. Dùng **Giải phóng RAM tab nền** rồi xác nhận, hoặc tự đóng ứng dụng không dùng. Nghỉ sâu có thể bỏ nội dung ô nhập chưa gửi.
5. Trang không phản hồi có nút **Khôi phục tab** và **Chẩn đoán trình duyệt** ngay phía trên. **Trình duyệt > menu thêm > Khôi phục tab** cũng dùng được trước khi runtime báo lỗi. Khôi phục tạo lại tab, giữ địa chỉ và zoom, xác minh vùng render mới trước khi hiện. Ô nhập chưa gửi có thể mất. Thao tác do bạn chủ động chọn, không tự tải trang lặp lại.
6. QuietShare giữ nguyên thiết lập pagefile của Windows. Nếu bộ nhớ cam kết vẫn đầy khi chỉ mở một tab, cần xem thêm phần bộ nhớ đang dùng ở nơi khác trong Windows.

Mục lịch sử mới từ v0.23.1 có bộ nhớ cam kết và RAM vật lý còn trống/tổng giới hạn tại lúc lỗi. Mục v0.23.0 cũ được giữ, ghi rõ chưa có số liệu bộ nhớ. Bộ nhớ tại lúc xuất là bản đo riêng. Ứng dụng kiểm tra áp lực bộ nhớ tối đa mỗi hai giây và dùng ngưỡng phục hồi khác để cảnh báo không nhấp nháy.
