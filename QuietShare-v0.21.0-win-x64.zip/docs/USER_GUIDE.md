# User guide / Hướng dẫn sử dụng

**Visual step-by-step guides / Hướng dẫn bằng ảnh:** [Tiếng Việt](VISUAL_GUIDE_VI.md) · [English](VISUAL_GUIDE_EN.md).

[Overview](../README.md) · [Privacy](PRIVACY.md) · [Troubleshooting](TROUBLESHOOTING.md)

[Giới thiệu](../README.md) · [Quyền riêng tư](PRIVACY.md) · [Xử lý sự cố](TROUBLESHOOTING.md)

## Install and update / Cài đặt và nâng cấp

**English**

1. Download from the [release page](https://github.com/TDUmii/QuietShare/releases/latest).
2. Run **QuietShare-Setup.exe** for a per-user installation without administrator access. The installer supports English and Vietnamese.
3. For portable use, extract the complete ZIP. Keep Scintilla.dll, Lexilla.dll, pdfium.dll and WebView2Loader.dll beside QuietShare.exe.
4. Close the app before updating. Upgrading or uninstalling preserves saved scripts.

**Tiếng Việt**

1. Tải từ [trang phát hành](https://github.com/TDUmii/QuietShare/releases/latest).
2. Chạy **QuietShare-Setup.exe** để cài cho tài khoản hiện tại, không cần quyền quản trị. Bộ cài có tiếng Anh và tiếng Việt.
3. Nếu dùng portable, giải nén toàn bộ ZIP. Giữ Scintilla.dll, Lexilla.dll, pdfium.dll và WebView2Loader.dll cạnh QuietShare.exe.
4. Đóng ứng dụng trước khi nâng cấp. Nâng cấp hoặc gỡ cài đặt vẫn giữ lời nhắc đã lưu.

## Files and projects / File và dự án

Home places compact **Open file** and **Open project** actions above a full-width list of real recent work. Protection status appears in a separate section. Use the compact icon rail and its tooltips to switch workspaces.

Trang chủ đặt hai nút gọn **Mở file** và **Mở dự án** trên danh sách công việc gần đây toàn chiều rộng. Trạng thái bảo vệ nằm trong khu vực riêng. Dùng thanh biểu tượng gọn và chú giải để chuyển không gian làm việc.

- **Open files:** choose **Open file / Ctrl+O** or drag local files into the app.
- **Open a project folder:** press **Ctrl+Shift+O**.
- **Find common folders:** the protected picker provides Desktop, Downloads, Documents, Pictures and drive shortcuts.
- **Use Explorer:** press **Ctrl+B** to show or hide it. Double-click or press Enter to open a selected file.
- Explorer skips junctions/symlinks and, by default, hidden/heavy development folders.

- **Mở file:** chọn **Mở file / Ctrl+O** hoặc kéo file cục bộ vào ứng dụng.
- **Mở thư mục dự án:** nhấn **Ctrl+Shift+O**.
- **Tìm thư mục quen thuộc:** hộp chọn được bảo vệ có lối tắt Desktop, Downloads, Documents, Pictures và ổ đĩa.
- **Dùng Explorer:** nhấn **Ctrl+B** để ẩn hoặc hiện. Nhấp đúp hoặc Enter để mở file đã chọn.
- Explorer bỏ qua junction/symlink và mặc định lọc thư mục ẩn hoặc thư mục phát triển nặng.

- **Recent history:** Home lists files and projects you actually opened.
- Pin favorites, remove one entry or clear all history, including pins. Removing history never deletes the original file.
- **Switch documents:** right-click **Open files** on the sidebar.
- Up to 32 documents, including the optional script, can be open. View positions are retained during the session.

- **Lịch sử gần đây:** Home hiển thị file và dự án bạn thực sự đã mở.
- Có thể ghim, xóa một mục hoặc xóa toàn bộ lịch sử gồm cả ghim. Xóa lịch sử không xóa file gốc.
- **Chuyển tài liệu:** nhấp phải **Tệp đang mở** ở thanh bên.
- Có thể mở tối đa 32 tài liệu tính cả lời nhắc tùy chọn. Vị trí xem được giữ trong phiên.

- **Edit:** text/code editing is enabled by default. Disable editing in **Settings > Reading & files** for viewing only.
- **Save:** use **Save / Ctrl+S**. Saving preserves supported encoding/BOM.
- **External changes:** saving refuses to overwrite a file changed externally. Reload or keep your current draft when prompted.
- **Close a modified file:** choose save, discard or cancel.
- Images and PDFs remain read-only. Source code is never executed.

- **Sửa:** văn bản/code mặc định cho phép sửa. Tắt sửa tại **Cài đặt > Đọc & tệp** để chỉ xem.
- **Lưu:** dùng **Lưu / Ctrl+S**. Ứng dụng giữ mã hóa/BOM được hỗ trợ.
- **Thay đổi bên ngoài:** ứng dụng chặn ghi đè nếu file đã đổi trong ứng dụng khác. Chọn tải lại hoặc giữ bản sửa khi được hỏi.
- **Đóng file đang sửa:** chọn lưu, bỏ thay đổi hoặc hủy.
- Ảnh và PDF chỉ đọc. Code không được thực thi.

## Scripts and reading / Lời nhắc và cách đọc

**English**

1. Right-click **Open files > Compose script** to prepare a script.
2. Press **Ctrl+Enter** to switch editing/reading.
3. Press **Space** in the reading area to start or pause auto-scroll.

Scripts autosave locally, separately from imported files.

**Tiếng Việt**

1. Nhấp phải **Tệp đang mở > Soạn lời nhắc** để chuẩn bị nội dung.
2. Nhấn **Ctrl+Enter** để chuyển soạn/đọc.
3. Nhấn **Space** trong vùng đọc để chạy hoặc dừng cuộn tự động.

Lời nhắc tự lưu trên máy, tách biệt với file đã mở.

- **Text/scripts:** use toolbar controls for size, regular/semibold/bold weight and word wrap. Text supports 8-200 pt.
- **Code:** use its wrap control. Code, images, PDFs and web pages support 25-400% zoom.
- **Defaults:** 50% zoom and 12 pt for text/scripts. Reset or **Ctrl+0** restores defaults.
- Formatting/theme changes preserve the visible reading anchor and selection. Formatting is not written into plain-text files.

- **Văn bản/lời nhắc:** dùng thanh xem để chỉnh cỡ chữ, độ đậm thường/vừa/đậm và xuống dòng. Cỡ chữ hỗ trợ 8-200 pt.
- **Code:** có nút xuống dòng riêng. Code, ảnh, PDF và web hỗ trợ zoom 25-400%.
- **Mặc định:** zoom 50% và 12 pt cho văn bản/lời nhắc. Đặt lại hoặc **Ctrl+0** để khôi phục.
- Đổi định dạng/theme giữ vùng đang đọc và vùng chọn. Định dạng không được ghi vào file text.

- **Search:** press **Ctrl+F**, then Enter/Shift+Enter for next/previous. Press Esc to close search.
- **PDF text:** search/copy requires a text layer.
- **PDF pages:** the PDF toolbar shows Previous, page number / total and Next, including in focus mode or when the main toolbar is hidden. With the PDF focused, use Page Up/Page Down or Left/Right to change pages. The overflow menu also offers Fit Width.
- **PDF movement:** the wheel changes pages when the whole page fits. On tall or zoomed pages, it pans to the edge, then the next wheel notch changes pages. Going back enters the previous page at its bottom. Up/Down scroll within and across pages. Ctrl+wheel zooms. Drag blank space to pan or drag text to select it.

- **Tìm kiếm:** nhấn **Ctrl+F**, sau đó Enter/Shift+Enter để tìm tiếp/trước. Nhấn Esc để đóng.
- **Chữ PDF:** cần lớp chữ để tìm/sao chép.
- **Trang PDF:** thanh công cụ PDF hiển thị nút trang trước, số trang / tổng số và trang sau, kể cả trong chế độ tập trung hoặc khi ẩn thanh công cụ chính. Khi PDF được chọn, dùng Page Up/Page Down hoặc Trái/Phải để đổi trang. Menu mở rộng vẫn có vừa chiều ngang.
- **Di chuyển trong PDF:** con lăn đổi trang khi toàn bộ trang vừa khung. Với trang dài hoặc phóng to, con lăn di chuyển đến mép rồi nấc cuộn tiếp theo mới đổi trang. Khi lùi, trang trước mở ở cuối trang. Lên/Xuống cuộn trong trang và qua trang. Ctrl+con lăn để zoom. Kéo vùng trống để di chuyển hoặc kéo trên chữ để chọn.

## Appearance / Giao diện

- Choose **Settings > Appearance > Color theme**, or the theme button in the viewer toolbar.
- Choices are Monochrome dark (default), Monochrome light, Warm paper, Midnight blue, Forest dark, Graphite, Soft mint, Daylight blue, High contrast black and High contrast white.
- Choose **Custom** to set background, panel, text and accent colors. QuietShare derives readable borders and surfaces from those four values and stores them locally. **Reset custom colors** restores the initial palette.
- Themes persist across launches. Image pixels, PDF pages and website colors remain unchanged.

- Chọn **Cài đặt > Giao diện > Chủ đề màu** hoặc nút theme trên thanh xem.
- Có Đơn sắc tối (mặc định), Đơn sắc sáng, Giấy ấm, Xanh đêm, Rừng đêm, Than chì, Sương xanh, Xanh ban ngày, Đen tương phản cao và Trắng tương phản cao.
- Chọn **Tùy chỉnh** để đặt màu nền, bảng, chữ và màu nhấn. QuietShare tự tạo viền và bề mặt có độ tương phản từ bốn màu này rồi lưu cục bộ. **Khôi phục màu theme mặc định** đưa bảng màu về ban đầu.
- Theme được nhớ qua các lần mở. Màu ảnh, trang PDF và website giữ nguyên.

- **Appearance settings:** language, always-on-top, window opacity (40-100%) and icon size (12-24 px).
- **Window size:** remembering the last size is enabled by default.
- **Opacity:** affects controller text as well. Public projection remains opaque.
- **Layout:** toggle bars and Explorer. Press **F11** for focus mode.
- **Resources:** presets limit projection processing to 15/30/60 fps. Actual performance depends on the display, GPU and content.

- **Cài đặt giao diện:** ngôn ngữ, ghim trên cùng, độ mờ cửa sổ (40-100%) và icon (12-24 px).
- **Kích thước cửa sổ:** nhớ kích thước lần cuối được bật mặc định.
- **Độ mờ:** tác động cả chữ cửa sổ điều khiển. Hình chiếu công khai vẫn đục.
- **Bố cục:** ẩn/hiện các thanh và Explorer. Nhấn **F11** vào chế độ tập trung.
- **Tài nguyên:** các chế độ giới hạn xử lý chiếu ở 15/30/60 fps. Hiệu năng thực tế tùy màn hình, GPU và nội dung.

## Optional browser / Trình duyệt tùy chọn

- **Enable:** use **Settings > Browser** or the browser page. Browsing requires WebView2 Runtime and starts disabled at each app launch.
- **Navigate:** the local New tab page accepts HTTP/HTTPS URLs, domains, localhost or search terms.
- **Tabs:** up to 8 share the local sign-in profile, with independent history/zoom during the session.
- **Tab labels:** Settings > Workspace can replace document or Browser titles with **Tab 1**, **Tab 2** and so on independently. Hovering still shows the full path or address.
- **Shortcuts:** up to 10 saved shortcuts persist. Open tabs are not restored next launch.

- **Bật:** dùng **Cài đặt > Trình duyệt** hoặc trang trình duyệt. Tính năng cần WebView2 Runtime và luôn tắt khi mới mở ứng dụng.
- **Điều hướng:** trang Tab mới cục bộ nhận URL HTTP/HTTPS, tên miền, localhost hoặc từ khóa.
- **Tab:** tối đa 8 tab dùng chung hồ sơ đăng nhập cục bộ, có lịch sử/zoom riêng trong phiên.
- **Nhãn tab:** trong Cài đặt > Bố cục có thể đổi riêng tên tab tài liệu hoặc Browser thành **Tab 1**, **Tab 2** và tiếp tục như vậy. Di chuột vẫn hiện đường dẫn hoặc địa chỉ đầy đủ.
- **Lối tắt:** tối đa 10 lối tắt được lưu. Danh sách tab mở không khôi phục ở lần chạy sau.

- **Ctrl+T** opens a tab. **Ctrl+W** closes it. Closing the last web tab disables browsing.
- New tabs must pass capture verification before user pages load.
- Background tabs receive suspension requests. Actual suspension depends on WebView2 and the page.
- Enabling web during projection holds the last public frame during verification, for up to about 5 seconds. Failure/cancellation stops projection.

- **Ctrl+T** mở tab. **Ctrl+W** đóng tab. Đóng tab web cuối cùng sẽ tắt trình duyệt.
- Tab mới phải qua xác minh capture trước khi tải trang người dùng.
- Tab nền nhận yêu cầu tạm ngưng. Việc tạm ngưng thực tế tùy WebView2 và trang web.
- Khi bật web lúc đang chiếu, ứng dụng giữ khung hình công khai gần nhất trong lúc xác minh, tối đa khoảng 5 giây. Thất bại/hủy sẽ dừng chiếu.

- Explicit **Ctrl+V** can paste raster images into compatible web editors.
- Web file pickers, file drops, downloads, screen sharing, notifications, DevTools and native context menus are blocked.
- Separate-popup sign-in flows may not work.
- Microphone/camera access is off by default. See [privacy](PRIVACY.md) for grant conditions.

## Meeting notebook / Sổ ghi chép cuộc họp

- Open **Meetings**, then **Export / more > Check playback and recognition**. Set language, output folder and optional Whisper model in **Settings > Meetings**. Small (466 MiB) prioritizes accuracy. Base (142 MiB) is lighter. Downloads require explicit Install.
- Start and stop recording yourself. Windows playback is the only audio source. No microphone or audio upload. Transcription runs locally with two background threads and a Cancel control.
- Review/edit segments, speakers and times. Mark decisions/action items, search and export TXT, timed VTT or Markdown minutes. Import provider VTT/TXT to preserve real speaker cues. Named speakers are not inferred from mixed audio.
- The notebook saves encrypted locally. Transcript only removes its temporary WAV after successful notebook save. Exports are ordinary readable files in the chosen folder. Use **Append transcript to the script** when wanted.
- Follow [chapter 12](USER_MANUAL_EN.md) for installation, review, exports and recovery.

- Mở **Cuộc họp**, chọn **Xuất / thêm > Kiểm tra nguồn âm thanh và nhận dạng**. Chọn ngôn ngữ, thư mục xuất và mô hình Whisper tùy chọn tại **Cài đặt > Cuộc họp**. Small (466 MiB) ưu tiên chính xác. Base (142 MiB) nhẹ hơn. Chỉ tải khi chủ động Cài.
- Tự bật/tắt ghi. Chỉ thu âm thanh phát Windows, không micro hoặc tải âm thanh lên mạng. Chép lời cục bộ dùng hai luồng nền và có nút Dừng xử lý.
- Duyệt/sửa đoạn, người nói và giờ. Đánh dấu quyết định/việc cần làm, tìm kiếm và xuất TXT, VTT có giờ hoặc biên bản Markdown. Nhập VTT/TXT nền tảng để giữ người nói thật. Không suy đoán tên từ âm thanh trộn.
- Sổ tự lưu mã hóa trên máy. Chỉ nội dung xóa WAV tạm sau khi lưu sổ thành công. File xuất đọc bình thường tại thư mục đã chọn. Chủ động **Thêm transcript vào lời nhắc** khi cần.
- Xem [chương 12](USER_MANUAL_VI.md) để biết cách cài, duyệt, xuất và phục hồi.

- Người dùng có thể chủ động **Ctrl+V** ảnh raster vào ô nhập web tương thích.
- Hộp chọn file web, thả file, tải xuống, chia sẻ màn hình, thông báo, DevTools và menu native bị chặn.
- Đăng nhập cần popup riêng có thể không hoạt động.
- Camera/micro mặc định tắt. Xem điều kiện cấp quyền tại [quyền riêng tư](PRIVACY.md).

## Supported content / Nội dung hỗ trợ

| Type | Limits / Giới hạn |
|---|---|
| Text and code / Văn bản và code | UTF-8 or UTF-16 with BOM, up to 5 MiB. Unknown extensions need valid text encoding and no binary content.<br>UTF-8 hoặc UTF-16 có BOM, tối đa 5 MiB. Đuôi lạ phải là văn bản hợp lệ, không chứa dữ liệu nhị phân. |
| Images / Ảnh | PNG, JPEG, BMP and the first GIF frame. Up to 25 MiB and 40 megapixels.<br>PNG, JPEG, BMP và khung đầu GIF. Tối đa 25 MiB, 40 megapixel. |
| PDF | Up to 64 MiB and 10,000 pages. One rendered page at a time, no password support.<br>Tối đa 64 MiB và 10.000 trang. Dựng từng trang, chưa hỗ trợ mật khẩu. |
| Local paths / Đường dẫn cục bộ | Local files/folders only. Executables, installers, archives and binaries are rejected.<br>Chỉ file/thư mục cục bộ. Từ chối tệp thực thi, bộ cài, tệp nén và nhị phân. |

## Default shortcuts / Phím tắt mặc định

| Shortcut | Action / Thao tác |
|---|---|
| F8 | Mask content and stop projection/scrolling. Press again to reveal when protection permits.<br>Che nội dung, dừng chiếu/cuộn. Nhấn lại để mở khi điều kiện bảo vệ cho phép. |
| Ctrl+Alt+Q | Recall QuietShare while preserving foreground focus and masking state.<br>Gọi lại QuietShare, giữ focus hiện tại và trạng thái che. |
| F9 / F10 | Verify WGC / start or stop projection.<br>Kiểm tra WGC / bắt đầu hoặc dừng chiếu. |
| F11 | Toggle focus mode.<br>Bật/tắt chế độ tập trung. |
| Ctrl+O / Ctrl+Shift+O | Open files / a folder.<br>Mở file / thư mục. |
| Ctrl+S / Ctrl+B | Save text/code / toggle Explorer.<br>Lưu văn bản/code / ẩn hiện Explorer. |
| Ctrl+Tab / Ctrl+Shift+Tab | Next/previous document or web tab on its active page.<br>Tab tài liệu hoặc web tiếp/trước trên trang đang dùng. |
| Ctrl+Enter / Space | Script edit/read / auto-scroll in reading mode.<br>Soạn/đọc lời nhắc / cuộn tự động trong chế độ đọc. |
| Ctrl+F / Ctrl+0 | Find / reset content zoom or size.<br>Tìm kiếm / đặt lại zoom hoặc cỡ chữ. |

- F8 and Ctrl+Alt+Q are global when registration succeeds.
- Other shortcuts depend on the focused area.
- Change ten shortcuts in **Settings > Shortcuts**. Reserved or duplicate bindings are rejected.

- F8 và Ctrl+Alt+Q dùng toàn hệ thống khi đăng ký thành công.
- Phím khác tùy vùng đang nhận focus.
- Đổi mười phím tắt tại **Cài đặt > Phím tắt**. Tổ hợp trùng hoặc dành riêng bị từ chối.

## Quick switch and saved sets / Chuyển nhanh và bộ đã lưu

- **Ctrl+K** searches open documents, browser tabs, commands and saved presentation sets.
- Choose **Presentation sets** to save up to eight named collections with script, local file paths and reading positions. Save edited files first.
- Opening a set asks before replacing tabs and retains the previous script in an encrypted recovery copy. It never starts projection or browsing automatically.
- **Presentation** now includes source/target selectors, Refresh, code-specific Recovery and a live preview of the outgoing stream, up to 10 FPS. A physical receiver remains unverified.

- **Ctrl+K** tìm tài liệu đang mở, tab web, lệnh và bộ thuyết trình đã lưu.
- Chọn **Bộ thuyết trình** để lưu tối đa tám bộ có tên, gồm lời nhắc, đường dẫn file và vị trí đọc. Lưu file đang sửa trước.
- Mở bộ cần xác nhận thay tab và giữ lời nhắc trước đó trong bản dự phòng mã hóa. Ứng dụng không tự bật chiếu hay trình duyệt.
- **Trình chiếu** có chọn nguồn/đích, Làm mới, Hướng xử lý theo mã lỗi và xem trước luồng đang gửi, tối đa 10 FPS. Đầu nhận vật lý vẫn chưa được xác minh.

## Optional reading panels / Vùng đọc tùy chọn

- The PDF menu offers visible-row thumbnails, bookmarks, go-to-page and a page-linked script reader. Use Markdown headings for sections and **Link page**, then enable **Sync** if wanted. Hide panels to reclaim space and thumbnail memory.
- Turn outgoing preview off in Presentation or Settings > Projection. The choice persists. Off frees preview GPU resources.

- Menu PDF có ảnh thu nhỏ theo dòng đang thấy, dấu trang, đến trang và vùng lời nhắc gắn trang. Dùng tiêu đề Markdown để chia phần rồi **Gắn trang**, bật **Đồng bộ** khi cần. Ẩn vùng để lấy lại diện tích và bộ nhớ ảnh thu nhỏ.
- Tắt xem trước tại Trình chiếu hoặc Cài đặt > Trình chiếu. Lựa chọn được nhớ. Tắt giải phóng tài nguyên GPU của xem trước.

## Settings and recovery / Cài đặt và phục hồi

Settings has eight left categories, a compact picker in small windows and collapsed Appearance > Advanced options. Save/apply three personal profiles in Workspace. Data holds Clear history. Meetings holds recording and recognition settings.

Cài đặt có tám nhóm bên trái, nút chọn khi cửa sổ nhỏ và Giao diện > Nâng cao có thể mở gọn. Lưu/áp dụng ba hồ sơ riêng trong Bố cục. Dữ liệu chứa Xóa lịch sử. Cuộc họp chứa thiết lập ghi và nhận dạng.

Open Last-stop diagnostics from Projection or Browser. For a stopped browser tab, use Reload tab to recreate and reverify. QS-P protection failures still require repair, F9 and explicit F10. See the [error book](BOOK.md).

Mở Chẩn đoán lần dừng từ Trình chiếu hoặc Trình duyệt. Tab web dừng có nút Tải lại tab để tạo và xác minh lại. Lỗi bảo vệ QS-P vẫn cần khắc phục, F9 rồi chủ động F10. Xem [book mã lỗi](BOOK.md).
